package com.test.mod.module.modules.combat;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.test.mod.Utils.ChatUtils;
import com.test.mod.Utils.Tools;
import com.test.mod.Utils.Utils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.module.modules.other.Teams;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemSword;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import org.lwjgl.input.Mouse;

public class AimBot extends Module {

    public ModeSetting priority= new ModeSetting("Priority", "Closest", Arrays.asList("Closest","Health"),this);
    public EnableSetting walls = new EnableSetting("ThroughWalls", false);
    public EnableSetting clickAim = new EnableSetting("ClickAim", false);
    public EnableSetting Click=new EnableSetting("ClickAim", true);

    public static IntegerSetting yaw = new IntegerSetting("Yaw", 15.0D, 0D, 50D,0);
    public static IntegerSetting pitch = new IntegerSetting("Pitch", 15.0D, 0D, 50D,0);
    public IntegerSetting range= new IntegerSetting("Range", 4.7D, 0.1D, 10D,1);
    public IntegerSetting FOV = new IntegerSetting("FOV", 90D, 1D, 180D,0);

    public IntegerSetting horizontal;
    public IntegerSetting vertical;

    public EntityLivingBase target;

    public AimBot() {
        super("AimBot",0, ModuleType.Combat,false);
        add(priority, walls,clickAim, yaw, pitch, range, FOV,Click);
    }

    @Override
    public void onDisable() {
        this.target = null;
        super.onDisable();
    }

    @SubscribeEvent
    public void onClientTick(ClientTickEvent event) {
        if (Tools.nullCheck())return;
        updateTarget();
        if ( mc.thePlayer.getHeldItem() == null ||  mc.thePlayer.getHeldItem().getItem() == null) {
            return;
        }

        final Item heldItem = mc.thePlayer.getHeldItem().getItem();
        if (Click.getEnable()){
            if (!Mouse.isButtonDown(0))return;
        }

        Utils.assistFaceEntity(
                this.target,
                (float) this.yaw.getCurrent(),
                (float) this.pitch.getCurrent());
        this.target = null;

    }

    private int randomNumber()
    {
        return -1 + (int)(Math.random() * ((1 - (-1)) + 1));
    }
    void updateTarget(){
        for (Object object : Utils.getEntityList()) {
            if(!(object instanceof EntityLivingBase)) continue;
            EntityLivingBase entity = (EntityLivingBase) object;
            if(!check(entity)) continue;
            this.target = entity;
        }
    }
    public static boolean isInAttackFOV(EntityLivingBase entity, int fov) {
        return Utils.getDistanceFromMouse(entity) <= fov;
    }
    public static boolean isInAttackRange(EntityLivingBase entity, float range) {
        return entity.getDistanceToEntity(mc.thePlayer) <= range;
    }
    public boolean check(EntityLivingBase entity) {
        if(entity instanceof EntityArmorStand) { return false; }
        if(entity ==  mc.thePlayer) { return false; }
        if(entity.isDead) { return false; }
        if(!isInAttackFOV(entity, (int)FOV.getCurrent())) { return false; }
        if(!isInAttackRange(entity, (float) range.getCurrent())) { return false; }
        if(!Teams.isTeam(entity)) { return false; }
        if(!isPriority(entity)) { return false; }
        if(!this.walls.getEnable()) { if(! mc.thePlayer.canEntityBeSeen(entity)) { return false; } }
        return true;
    }
    public static boolean isClosest(EntityLivingBase entity, EntityLivingBase entityPriority) {
        return entityPriority == null ||  mc.thePlayer.getDistanceToEntity(entity) <  mc.thePlayer.getDistanceSqToEntity(entityPriority);
    }
    public static boolean isLowHealth(EntityLivingBase entity, EntityLivingBase entityPriority) {
        return entityPriority == null || entity.getHealth() < entityPriority.getHealth();
    }
    boolean isPriority(EntityLivingBase entity) {
        return priority.getCurrent().equals("Closest") && isClosest(entity, target)
                || priority.getCurrent().equals("Health") && isLowHealth(entity, target);
    }

    private EntityLivingBase getBestEntity()
    {
        List<EntityLivingBase> loaded = new CopyOnWriteArrayList<>();

        for (Object o : mc.theWorld.getLoadedEntityList())
        {
            if (o instanceof EntityLivingBase)
            {
                EntityLivingBase ent = (EntityLivingBase) o;

                if (ent.isEntityAlive() && ent instanceof EntityPlayer && ent
                        .getDistanceToEntity( mc.thePlayer) < range.getCurrent()
                        && fovCheck(ent))
                {
                    /*if (ent == Killaura.vip)
                    {
                        return ent;
                    }*/

                    loaded.add(ent);
                }
            }
        }

        if (loaded.isEmpty())
        {
            return null;
        }

        try
        {
            loaded.sort((o1, o2) ->
            {
                float[] rot1 = Utils.getRotations(o1);
                float[] rot2 = Utils.getRotations(o2);
                return (int)((Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationYaw, rot1[0])
                        + Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationPitch, rot1[1]))
                        - (Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationYaw, rot2[0])
                        + Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationPitch, rot2[1])));
            });
        }
        catch (Exception e)
        {
            ChatUtils.error("Exception with TM: " + e.getMessage());
        }

        return loaded.get(0);
    }
    private boolean fovCheck(EntityLivingBase ent)
    {
        float[] rotations = Utils.getRotations(ent);
        float dist =  mc.thePlayer.getDistanceToEntity(ent);

        if (dist == 0)
        {
            dist = 1;
        }

        float yawDist = Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationYaw, rotations[0]);
        float pitchDist = Utils.getDistanceBetweenAngles(  mc.thePlayer.rotationPitch, rotations[1]);
        float fovYaw = (float) yaw.getCurrent() * 3 / dist;
        float fovPitch = ((float) pitch.getCurrent() * 3) / dist;
        return yawDist < fovYaw && pitchDist < fovPitch;
    }

}
