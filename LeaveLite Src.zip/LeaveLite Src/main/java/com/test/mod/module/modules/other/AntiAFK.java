package com.test.mod.module.modules.other;

import com.test.mod.Utils.TimerUtils;
import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class AntiAFK extends Module {
    private TimerUtils timerUtils=new TimerUtils();
    public AntiAFK() {

        super("AntiAFK", Keyboard.KEY_NONE, ModuleType.Other,false);
    }
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if(!Tools.isPlayerInGame())return;
        if (timerUtils.isDelayComplete(2000.0d)) {
            mc.thePlayer.jump();
            timerUtils.reset();
        }

    }

}
