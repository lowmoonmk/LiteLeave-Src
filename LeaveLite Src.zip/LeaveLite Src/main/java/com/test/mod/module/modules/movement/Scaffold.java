package com.test.mod.module.modules.movement;


import com.test.mod.Utils.ReflectionUtil;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class Scaffold extends Module {
    public Scaffold() {
        super("Scaffold", Keyboard.KEY_NONE, ModuleType.Movement,false);
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }


    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        Eagle();
    }
    void Eagle() {
        try {
            if (((mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock)) && (!this.mc.gameSettings.keyBindJump.isPressed())) {
                BlockPos bp = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0D, mc.thePlayer.posZ);
                if (mc.theWorld.getBlockState(bp).getBlock() == Blocks.air && !Keyboard.isKeyDown(Keyboard.KEY_W)) {
                    ReflectionUtil.pressed.set(Minecraft.getMinecraft().gameSettings.keyBindSneak, true);
                } else {
                    ReflectionUtil.pressed.set(Minecraft.getMinecraft().gameSettings.keyBindSneak, false);
                }
            }
        } catch (Exception localException) {
        }

    }

}
