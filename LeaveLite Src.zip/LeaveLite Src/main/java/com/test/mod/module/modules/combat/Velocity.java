package com.test.mod.module.modules.combat;

import com.test.mod.Utils.Connection;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.Arrays;

public class Velocity extends Module {
    public ModeSetting mode = new ModeSetting("Mode","Simple", Arrays.asList("Simple","Legit","AAC","Ghost"),this);

    public IntegerSetting chance= new IntegerSetting("Chance",90D,0D,100D,0);
    public IntegerSetting hori= new IntegerSetting("Horizon",90D,0D,100D,0);
        public IntegerSetting verti= new IntegerSetting("Verti",90D,0D,100D,0);
    public Velocity() {
        super("Velocity",0,ModuleType.Combat,false);
        add(mode,hori,chance,verti);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (mode.getCurrent().equals("AAC")) {
            EntityPlayerSP player = mc.thePlayer;
            if (player.hurtTime > 0 && player.hurtTime <= 7) {
                player.motionX *= 0.5;
                player.motionZ *= 0.5;
            }
            if (player.hurtTime > 0 && player.hurtTime < 6) {
                player.motionX = 0.0;
                player.motionZ = 0.0;
            }
        }else if(mode.getCurrent().equals("Legit")){
            if (mc.thePlayer.maxHurtResistantTime != mc.thePlayer.hurtResistantTime || mc.thePlayer.maxHurtResistantTime == 0) {
                return;
            }

            Double random = Math.random();
            random *= 100.0;

            if(random < (int)this.chance.getCurrent()) {
                float hori = (float) this.hori.getCurrent();
                hori /= 100.0f;
                float verti = (float) this.verti.getCurrent();
                verti /= 100.0f;
                mc.thePlayer.motionX *= hori;
                mc.thePlayer.motionZ *= hori;
                mc.thePlayer.motionY *= verti;
            } else {
                mc.thePlayer.motionX *= 1.0f;
                mc.thePlayer.motionY *= 1.0f;
                mc.thePlayer.motionZ *= 1.0f;
            }
        }

    }


    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent ev) {
        if (mode.getCurrent().equals("Ghost")) {
            if (mc.thePlayer.maxHurtTime > 0 && mc.thePlayer.hurtTime == mc.thePlayer.maxHurtTime) {

                if (chance.getCurrent() != 100.0D) {
                    double ch = Math.random();
                    if (ch >= chance.getCurrent() / 100.0D) {
                        return;
                    }
                }

                if (hori.getCurrent() != 100.0D) {
                    mc.thePlayer.motionX *= hori.getCurrent() / 100.0D;
                    mc.thePlayer.motionZ *= hori.getCurrent() / 100.0D;
                }

                if (verti.getCurrent() != 100.0D) {
                    mc.thePlayer.motionY *= verti.getCurrent() / 100.0D;
                }
            }
        }

    }

    @Override
    public boolean onPacket(Object packet, Connection.Side side) {
        if ((packet instanceof S12PacketEntityVelocity) && mode.getCurrent().equals("Simple")
                && mc.thePlayer.hurtTime >= 0) {
            S12PacketEntityVelocity p = (S12PacketEntityVelocity) packet;
            if (p.getEntityID() == mc.thePlayer.getEntityId()) {
                return false;
            }
        }
        return true;
    }

}
