package com.test.mod.module.modules.combat;

import com.test.mod.Utils.TimerUtils;
import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.world.World;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;
import java.nio.ByteBuffer;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class AutoClicker extends Module {
    private Random random;

    private long lastClick;
    private long hold;


    private double speed;
    private double holdLength;
    private double min;
    private double max;
    private boolean hasSelectedBlock;

    private static Field FmouseButton;
    private static Field FmouseButtons;
    private static Field FmouseButtonState;

    public boolean isDone = true;

    public int timer;
    private IntegerSetting maxcps = new IntegerSetting("MaxCPS", 13.0D, 1.0D, 20.0D,1);;
    private IntegerSetting mincps = new IntegerSetting("MinCPS", 9.0D, 1.0D, 20.0D,1);
    private double jitteryaw = 0.5D;
    private double jitterpitch = 0.5D;
  //private BooleanValue reflect = new BooleanValue("Reflect", false);
    private EnableSetting jitter= new EnableSetting("Jitter", false);
    //private EnableSetting weapon= new EnableSetting("Weapon", false);
    private EnableSetting BlockHit= new EnableSetting("Block_Hit", false);
    private EnableSetting BreakBlocks = new EnableSetting("Break_Blocks", true);
    private EnableSetting cpsdBypass = new EnableSetting("Cps_Bypass", false);
    public AutoClicker() {
        super("AutoClicker",0,ModuleType.Combat,false);
        add(maxcps,mincps,jitter,BlockHit,BreakBlocks,cpsdBypass);
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        click();
    }

    @Override
    public void onDisable() {
        isDone=true;
        super.onDisable();
    }
    public void jitter(Random rand) {
        if (rand.nextBoolean()) {
            if (rand.nextBoolean()) {
                mc.thePlayer.rotationPitch -= (float) (rand.nextFloat() * 0.6);
            } else {
                mc.thePlayer.rotationPitch += (float) (rand.nextFloat() * 0.6);
            }
        } else if (rand.nextBoolean()) {
            mc.thePlayer.rotationYaw -= (float) (rand.nextFloat() * 0.6);
        } else {
            mc.thePlayer.rotationYaw += (float) (rand.nextFloat() * 0.6);
        }
    }

    private long getDelay() {
        return (long) ((int)this.maxcps.getCurrent() + this.random.nextDouble()
                * ((int)this.mincps.getCurrent() - (int)this.maxcps.getCurrent()));
    }
    private long leftHold, rightHold;
    public void click() {
        if(Tools.nullCheck()) return;
        if(!Tools.isPlayerInGame())return;
        if (this.mc.currentScreen == null) {
            if (BreakBlocks.getEnable() && getIfSelectingBlock(hasSelectedBlock)) {
                return;
            }
            double speedLeft1 = 1.0 / io.netty.util.internal.ThreadLocalRandom.current().nextDouble(mincps.getCurrent() - 0.2D, maxcps.getCurrent());

            double leftHoldLength = speedLeft1 / io.netty.util.internal.ThreadLocalRandom.current().nextDouble(mincps.getCurrent() - 0.02D, maxcps.getCurrent());

            if (Mouse.isButtonDown(0)) {
                if (this.jitter.getEnable()) {
                    double a = 1 * 0.45D;
                    EntityPlayerSP entityPlayer;
                    if (this.random.nextBoolean()) {
                        entityPlayer = mc.thePlayer;
                        entityPlayer.rotationYaw = (float) ((double) entityPlayer.rotationYaw + (double) this.random.nextFloat() * a);
                    } else {
                        entityPlayer = mc.thePlayer;
                        entityPlayer.rotationYaw = (float) ((double) entityPlayer.rotationYaw - (double) this.random.nextFloat() * a);
                    }

                    if (this.random.nextBoolean()) {
                        entityPlayer = mc.thePlayer;
                        entityPlayer.rotationPitch = (float) ((double) entityPlayer.rotationPitch + (double) this.random.nextFloat() * a * 0.45D);
                    } else {
                        entityPlayer = mc.thePlayer;
                        entityPlayer.rotationPitch = (float) ((double) entityPlayer.rotationPitch - (double) this.random.nextFloat() * a * 0.45D);
                    }
                }
                double speedLeft = 1.0 / ThreadLocalRandom.current().nextDouble(mincps.getCurrent() - 0.2, maxcps.getCurrent());
                if (System.currentTimeMillis() - lastClick > speedLeft * 1000) {
                    lastClick = System.currentTimeMillis();
                    if (leftHold < lastClick) {
                        leftHold = lastClick;
                    }
                    int key = mc.gameSettings.keyBindAttack.getKeyCode();
                    KeyBinding.setKeyBindState(key, true);

                    KeyBinding.onTick(key);
                    Tools.setMouseButtonState(0, true);
                } else if (System.currentTimeMillis() - leftHold > leftHoldLength * 1000) {
                    KeyBinding.setKeyBindState(mc.gameSettings.keyBindAttack.getKeyCode(), false);

                    Tools.setMouseButtonState(0, false);
                }
            }
        }
    }
    private boolean canByp() {
        if (FmouseButtonState == null) {
            return false;
        }
        if (FmouseButton == null) {
            return false;
        }
        if (FmouseButtons == null) {
            return false;
        }
        return cpsdBypass.getEnable();
    }


    public static void setMouseButtonState(int mouseButton, boolean state) {
        MouseEvent e = new MouseEvent();
        FmouseButton.setAccessible(true);
        try {
            FmouseButton.set(e, mouseButton);
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        }
        FmouseButton.setAccessible(false);
        FmouseButtonState.setAccessible(true);
        try {
            FmouseButtonState.set(e, state);
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        }
        FmouseButtonState.setAccessible(false);
        MinecraftForge.EVENT_BUS.post(e);
        try {
            FmouseButtons.setAccessible(true);
            ByteBuffer buffer = (ByteBuffer) FmouseButtons.get(null);
            FmouseButtons.setAccessible(false);
            buffer.put(mouseButton, (byte) (state ? 1 : 0));
        } catch (IllegalAccessException e1) {
            e1.printStackTrace();
        }
    }


    private boolean getIfSelectingBlock(boolean state) {
        BlockPos bpos;
        World w;
        MovingObjectPosition objectPosition;
        EntityPlayerSP playerSP;
        if (mc.getRenderViewEntity() != null && (playerSP = mc.thePlayer) != null && playerSP instanceof EntityPlayerSP && (objectPosition = mc.getRenderViewEntity().rayTrace(4.8, 1.0f)) != null && (w = mc.thePlayer.worldObj) != null && objectPosition.hitVec != null && (bpos = new BlockPos(objectPosition.hitVec.xCoord, objectPosition.hitVec.yCoord, objectPosition.hitVec.zCoord)) != null) {
            Material material = w.getBlockState(bpos).getBlock().getMaterial();
            if (w.getBlockState(bpos).getBlock() != null && material != null && objectPosition.typeOfHit != null && mc.objectMouseOver != null) {
                if (mc.objectMouseOver.entityHit != null) {
                    state = false;
                } else if (objectPosition.typeOfHit != MovingObjectPosition.MovingObjectType.MISS) {
                    state = true;
                } else if (objectPosition.typeOfHit != MovingObjectPosition.MovingObjectType.BLOCK) {
                    state = false;
                }
            }
        }
        return state;
    }

    @Override
    public void onEnable() {
        random = new Random();
        this.updateVals();
    }
    private void updateVals() {

        try {
            Field LF = Minecraft.class.getDeclaredField("leftClickCounter");
            LF.setAccessible(true);
            LF.set(Minecraft.getMinecraft(), 0);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        min = mincps.getCurrent();
        max = maxcps.getCurrent();

        if (min >= max) {
            max = min + 1;
        }

        speed = 1.0 / ThreadLocalRandom.current().nextDouble(min - 0.2, max);
        holdLength = speed / ThreadLocalRandom.current().nextDouble(min, max);

        //M1
        isDone=true;
        timer=0;
    }

    static {

        try {
            FmouseButton = MouseEvent.class.getDeclaredField("button");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }

        try {
            FmouseButtonState = MouseEvent.class.getDeclaredField("buttonstate");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
        try {
            FmouseButtons = Mouse.class.getDeclaredField("buttons");
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    public void clickMouse() {

        mc.thePlayer.swingItem();

        if (mc.objectMouseOver != null) {
            switch (mc.objectMouseOver.typeOfHit) {
                case ENTITY:
                    mc.playerController.attackEntity(mc.thePlayer, mc.objectMouseOver.entityHit);
                    break;
                case BLOCK:
                    BlockPos blockpos = mc.objectMouseOver.getBlockPos();

                    if (mc.theWorld.getBlockState(blockpos).getBlock().getMaterial() != Material.air) {
                        mc.playerController.clickBlock(blockpos, mc.objectMouseOver.sideHit);
                        break;
                    }

                case MISS:
                default:

            }
        }

    }
}
