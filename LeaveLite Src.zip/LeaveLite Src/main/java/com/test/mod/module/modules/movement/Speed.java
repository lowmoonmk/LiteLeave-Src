package com.test.mod.module.modules.movement;

import com.test.mod.Utils.*;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockIce;
import net.minecraft.block.BlockPackedIce;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.potion.Potion;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Timer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.util.Arrays;
import java.util.List;

public class Speed extends Module {
    public boolean shouldslow = false;
    double count = 0;
    int jumps;
    private float air, ground, aacSlow;
    public static TimerUtils timer = new TimerUtils();
    boolean collided = false, lessSlow;
    int spoofSlot = 0;
    double less, stair;
    private double speed, speedvalue;
    private double lastDist;
    public static int stage, aacCount;
    public static Timer timers=ReflectionHelper.getPrivateValue(Minecraft.class,mc, new String[]{Mappings.timer});

    double movementSpeed;

    TimerUtils aac = new TimerUtils();
    TimerUtils lastFall = new TimerUtils();
    TimerUtils lastCheck = new TimerUtils();

    Timer mctimer = ReflectionHelper.getPrivateValue(Minecraft.class, mc,
            new String[] { Mappings.timer });

    // NCP
    private int level = 1;
    private double moveSpeed = 0.2873;
    private double lastDist_ = 0.0;
    private int timerDelay = 0;

    //Hypixel
    private ModeSetting mode = new ModeSetting("Mode", "New", Arrays.asList("Basic","Old","BHOP","OnGround","AAC","New"),this);
    private IntegerSetting speedVaule = new IntegerSetting("SpeedValue",0.25D,0.01D,10.0D,2);
    private EnableSetting lagback = new EnableSetting("LagBack",true);
    private EnableSetting fastfall = new EnableSetting("FastFall",false);

    public Speed() {
        super("Speed",0, ModuleType.Movement,false);
        getSettings().add(mode);
        getSettings().add(speedVaule);
        getSettings().add(lagback);
        getSettings().add(fastfall);
    }

    @Override
    public void onEnable() {
        less = 0;
        jumps = 0;
        count = 0;
        lastDist = 0.0;
        stage = 2;
        air = 0;

        timers.timerSpeed = 1;
        super.onEnable();
    }
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
       if(mode.getCurrent().equals("OnGround")){
            timers.timerSpeed=1.085f;
            double forward = mc.thePlayer.movementInput.moveForward;
            double strafe = mc.thePlayer.movementInput.moveStrafe;

            if ((forward != 0 || strafe != 0) && !mc.gameSettings.keyBindJump.isKeyDown()&& !mc.thePlayer.isInWater() && !mc.thePlayer.isOnLadder() && (!mc.thePlayer.isCollidedHorizontally))
            {
                if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, 0.4d, 0.0D)).isEmpty())
                {
                  //  mc.thePlayer.rotationYaw= mc.thePlayer.posY + (mc.thePlayer.ticksExisted % 2 != 0 ? 0.2 : 0);
                }
                else
                {
                  //  event.setY(mc.thePlayer.posY + (mc.thePlayer.ticksExisted % 2 != 0 ? 0.4198 : 0));
                }
            }

            speed = Math.max(mc.thePlayer.ticksExisted % 2 == 0 ? 2.1 : 1.3, MoveUtils.defaultSpeed());
            float yaw = mc.thePlayer.rotationYaw;

            if ((forward == 0.0D) && (strafe == 0.0D))
            {
                mc.thePlayer.motionX = (0.0D);
                mc.thePlayer.motionZ = (0.0D);
            }
            else
            {
                if (forward != 0.0D)
                {
                    if (strafe > 0.0D)
                    {
                        yaw += (forward > 0.0D ? -45 : 45);
                    }
                    else if (strafe < 0.0D)
                    {
                        yaw += (forward > 0.0D ? 45 : -45);
                    }

                    strafe = 0.0D;

                    if (forward > 0.0D)
                    {
                        forward = 0.15;
                    }
                    else if (forward < 0.0D)
                    {
                        forward = -0.15;
                    }
                }

                if (strafe > 0)
                {
                    strafe = 0.15;
                }
                else if (strafe < 0)
                {
                    strafe = -0.15;
                }

                mc.thePlayer.motionX = (forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F)));
                mc.thePlayer.motionZ = (forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F)));
            }
        }else if(mode.getCurrent().equals("New")){
            if (mc.thePlayer.onGround) {
                if (MoveUtils.isMoving()) {
                    mc.thePlayer.jump();
                    stage = 0;
                    speed = 1.10f;
                }
            }
            speed -= 0.004;
            MoveUtils.setSpeed(MoveUtils.getBaseMoveSpeed() * speed);
        }
    }
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if(mode.getCurrent().equals("Basic")){
            boolean boost = Math
                    .abs(mc.thePlayer.rotationYawHead - mc.thePlayer.rotationYaw) < 90;

            if (mc.thePlayer.moveForward > 0 && mc.thePlayer.hurtTime < 5) {
                if (mc.thePlayer.onGround) {
//            mc.thePlayer.jump();
                    mc.thePlayer.motionY = 0.405;
                    float f =getDirection();
                    mc.thePlayer.motionX -= (double) (MathHelper.sin(f) * 0.2F);
                    mc.thePlayer.motionZ += (double) (MathHelper.cos(f) * 0.2F);
                } else {
                    double currentSpeed = Math
                            .sqrt(mc.thePlayer.motionX * mc.thePlayer.motionX
                                    + mc.thePlayer.motionZ * mc.thePlayer.motionZ);
                    double speed = boost ? 1.0064 : 1.001;

                    double direction = getDirection();

                    mc.thePlayer.motionX = -Math.sin(direction) * speed * currentSpeed;
                    mc.thePlayer.motionZ = Math.cos(direction) * speed * currentSpeed;
                }
            }  

        }else  if(mode.getCurrent().equals("Old")){
            if (mc.thePlayer.isCollidedHorizontally) {
                collided = true;
            }

            if (collided) {
                // setTickLength(50);
                stage = -1;
            }

            if (stair > 0) {
                stair -= 0.25;
            }

            less -= less > 1 ? 0.12 : 0.11;

            if (less < 0) {
                less = 0;
            }

            if (!BlockUtils.isInLiquid() && MoveUtils.isOnGround(0.01) && (isMoving2())) {
                collided = mc.thePlayer.isCollidedHorizontally;

                if (stage >= 0 || collided) {
                    stage = 0;
                    double motY = 0.407 + MoveUtils.getJumpEffect() * 0.1;

                    if (stair == 0) {
                        mc.thePlayer.jump();

                        mc.thePlayer.motionY = motY;
                    } else {
                    }

                    less++;

                    if (less > 1 && !lessSlow) {
                        lessSlow = true;
                    } else {
                        lessSlow = false;
                    }

                    if (less > 1.12) {
                        less = 1.12;
                    }
                }
            }

            speed = getHypixelSpeed(stage) + 0.0331;
            speed *= 0.91;

            if (stair > 0) {
                speed *= 0.7 - MoveUtils.getSpeedEffect() * 0.1;
            }

            if (stage < 0) {
                speed = MoveUtils.defaultSpeed();
            }

            if (lessSlow) {
                speed *= 0.95;
            }

            if (BlockUtils.isInLiquid()) {
                speed = 0.55;
            }

            if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
                setMotion(speed);
                ++stage;
            }
        }else if(mode.getCurrent().equals("BHOP")){

            if (mc.thePlayer.moveForward == 0.0f && mc.thePlayer.moveStrafing == 0.0f) {
                speed = MoveUtils.defaultSpeed();
            }

            if (stage == 1 && mc.thePlayer.isCollidedVertically
                    && (mc.thePlayer.moveForward != 0.0f
                    || mc.thePlayer.moveStrafing != 0.0f)) {
                speed = 1.35 + MoveUtils.defaultSpeed() - 0.01;
            }

            if (!BlockUtils.isInLiquid() && stage == 2 && mc.thePlayer.isCollidedVertically
                    && MoveUtils.isOnGround(0.01) && (mc.thePlayer.moveForward != 0.0f
                    || mc.thePlayer.moveStrafing != 0.0f)) {
                if (Minecraft.getMinecraft().thePlayer.isPotionActive(Potion.jump)) {
                    mc.thePlayer.motionY = 0.41999998688698
                            + (Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.jump).getAmplifier() + 1)
                            * 0.1;
                    // em.setY(mc.thePlayer.motionY = 0.41999998688698 +
                    // (Minecraft.getMinecraft().thePlayer.getActivePotionEffect(Potion.jump).getAmplifier()
                    // + 1) * 0.1);
                } else {
                    mc.thePlayer.motionY = 0.41999998688698;
                }

                mc.thePlayer.jump();
                speed *= 1.533D;
            } else if (stage == 3) {
                final double difference = 0.66 * (lastDist - MoveUtils.defaultSpeed());
                speed = lastDist - difference;
            } else {
                final List collidingList = mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer,
                        mc.thePlayer.getEntityBoundingBox().offset(0.0, mc.thePlayer.motionY,
                                0.0));

                if ((collidingList.size() > 0 || mc.thePlayer.isCollidedVertically) && stage > 0) {
                    stage = ((mc.thePlayer.moveForward != 0.0f
                            || mc.thePlayer.moveStrafing != 0.0f) ? 1 : 0);
                }

                speed = lastDist - lastDist / 159.0;
            }

            speed = Math.max(speed, MoveUtils.defaultSpeed());

            // Stage checks if you're greater than 0 as step sets you -6 stage to make sure
            // the player wont flag.
            if (stage > 0) {
                // Set strafe motion.
                if (BlockUtils.isInLiquid()) {
                    speed = 0.1;
                }

                setMotion( speed);
            }

            // If the player is moving, step the stage up.
            if (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) {
                ++stage;
            }

        }else if(mode.getCurrent().equals("AAC")){
            if (mc.thePlayer.fallDistance > 1.2) {
                lastFall.reset();
            }

            if (!BlockUtils.isInLiquid() && mc.thePlayer.isCollidedVertically && MoveUtils.isOnGround(0.01)
                    && (mc.thePlayer.moveForward != 0.0f
                    || mc.thePlayer.moveStrafing != 0.0f)) {
                stage = 0;
                mc.thePlayer.jump();
                mc.thePlayer.motionY = (mc.thePlayer.motionY = 0.41999998688698
                        + MoveUtils.getJumpEffect());

                if (aacCount < 4) {
                    aacCount++;
                }
            }

            speed = getAACSpeed(stage, aacCount);

            if ((mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f)) {
                if (BlockUtils.isInLiquid()) {
                    speed = 0.075;
                }

                setMotion( speed);
            }

            if (mc.thePlayer.moveForward != 0.0f || mc.thePlayer.moveStrafing != 0.0f) {
                ++stage;
            }
        }
    }
    public static boolean isMoving2() {
        return ((mc.thePlayer.moveForward != 0.0F || mc.thePlayer.moveStrafing != 0.0F));
    }


    @Override
    public void onDisable() {
        Timer timer = ReflectionHelper.getPrivateValue(Minecraft.class, mc, new String[] { Mappings.timer });
        timer.timerSpeed = 1.0F;

        moveSpeed = baseMoveSpeed();
        level = 0;
        super.onDisable();
    }
    public static boolean MovementInput() {
        return mc.gameSettings.keyBindForward.isKeyDown()
                || mc.gameSettings.keyBindLeft.isKeyDown()
                || mc.gameSettings.keyBindRight.isKeyDown()
                || mc.gameSettings.keyBindBack.isKeyDown();
    }

    public static boolean MineLandMovementInput() {
        return (mc.gameSettings.keyBindLeft.isKeyDown()
                || mc.gameSettings.keyBindRight.isKeyDown()
                || mc.gameSettings.keyBindBack.isKeyDown())
                && !mc.gameSettings.keyBindForward.isKeyDown();
    }

    public static float getDirection() {
        float var1 = mc.thePlayer.rotationYaw;
        if (mc.thePlayer.moveForward < 0.0f) {
            var1 += 180.0f;
        }
        float forward = 1.0f;
        if (mc.thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (mc.thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (mc.thePlayer.moveStrafing > 0.0f) {
            var1 -= 90.0f * forward;
        }
        if (mc.thePlayer.moveStrafing < 0.0f) {
            var1 += 90.0f * forward;
        }
        return var1 *= 0.017453292f;
    }

    public static float getDirection(float yaw) {
        if (Minecraft.getMinecraft().thePlayer.moveForward < 0.0f) {
            yaw += 180.0f;
        }
        float forward = 1.0f;
        if (Minecraft.getMinecraft().thePlayer.moveForward < 0.0f) {
            forward = -0.5f;
        } else if (Minecraft.getMinecraft().thePlayer.moveForward > 0.0f) {
            forward = 0.5f;
        }
        if (Minecraft.getMinecraft().thePlayer.moveStrafing > 0.0f) {
            yaw -= 90.0f * forward;
        }
        if (Minecraft.getMinecraft().thePlayer.moveStrafing < 0.0f) {
            yaw += 90.0f * forward;
        }
        return yaw *= 0.017453292f;
    }

    public static void setSpeed(double speed) {
        mc.thePlayer.motionX = -Math.sin(getDirection()) * speed;
        mc.thePlayer.motionZ = Math.cos(getDirection()) * speed;
    }

    @Override
    public boolean onPacket(Object packet, Connection.Side side) {
        if (lagback.getEnable()) {
            if (side == Connection.Side.IN) {
                if (packet instanceof S08PacketPlayerPosLook) {
                    ChatUtils.warning("Lagback checks->Speed");
                    mc.thePlayer.onGround = false;
                    mc.thePlayer.motionX *= 0;
                    mc.thePlayer.motionZ *= 0;
                    mc.thePlayer.jumpMovementFactor = 0;
                    this.toggleModule(true);
                    stage = -4;
                }
            }

        }
        return super.onPacket(packet, side);
    }
    public int getSpeedEffect() {
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) {
            return mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
        }
        return 0;

    }

    private double defaultSpeed() {
        double baseSpeed = 0.2873;
        /*
         * if (mc.thePlayer.isPotionActive(Potion.moveSpeed)) { int amplifier =
         * mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
         * if(KillAura.getTarget() != null) {
         * if(Client.instance.getModuleManager().getModuleByClass(TargetStrafe.class).
         * isEnabled()) { if(TargetStrafe.key.getValue() == true) {
         * if(mc.gameSettings.keyBindJump.isKeyDown()) { baseSpeed *= 1.0 +
         * 0.20523462345623462435 * (double)(amplifier + 1); } else { baseSpeed *= 1.0 +
         * 0.26523462345623462435 * (double)(amplifier + 1); } }else { baseSpeed *= 1.0
         * + 0.20523462345623462435 * (double)(amplifier + 1); } }else { baseSpeed *=
         * 1.0 + 0.26523462345623462435 * (double)(amplifier + 1); } }else { baseSpeed
         * *= 1.0 + 0.26523462345623462435 * (double)(amplifier + 1); } }
         */
        return baseSpeed;
    }

    private double baseMoveSpeed() {
        double baseSpeed = 0.2873;
        if (mc.thePlayer.isPotionActive(Potion.moveSpeed))
            baseSpeed *= 1.0 + 0.2 * (mc.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1);
        return baseSpeed;
    }
    private double getAACSpeed(int stage, int jumps) {
        double value = 0.29;
        double firstvalue = 0.3019;
        double thirdvalue = 0.0286 - (double) stage / 1000;

        if (stage == 0) {
            // JUMP
            value = 0.497;

            if (jumps >= 2) {
                value += 0.1069;
            }

            if (jumps >= 3) {
                value += 0.046;
            }

            Block block = MoveUtils.getBlockUnderPlayer(mc.thePlayer, 0.01);

            if (block instanceof BlockIce || block instanceof BlockPackedIce) {
                value = 0.59;
            }
        } else if (stage == 1) {
            value = 0.3031;

            if (jumps >= 2) {
                value += 0.0642;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 2) {
            value = 0.302;

            if (jumps >= 2) {
                value += 0.0629;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 3) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0607;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 4) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0584;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 5) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0561;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 6) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0539;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 7) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0517;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 8) {
            value = firstvalue;

            if (MoveUtils.isOnGround(0.05)) {
                value -= 0.002;
            }

            if (jumps >= 2) {
                value += 0.0496;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 9) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0475;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 10) {
            value = firstvalue;

            if (jumps >= 2) {
                value += 0.0455;
            }

            if (jumps >= 3) {
                value += thirdvalue;
            }
        } else if (stage == 11) {
            value = 0.3;

            if (jumps >= 2) {
                value += 0.045;
            }

            if (jumps >= 3) {
                value += 0.018;
            }
        } else if (stage == 12) {
            value = 0.301;

            if (jumps <= 2) {
                aacCount = 0;
            }

            if (jumps >= 2) {
                value += 0.042;
            }

            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        } else if (stage == 13) {
            value = 0.298;

            if (jumps >= 2) {
                value += 0.042;
            }

            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        } else if (stage == 14) {
            value = 0.297;

            if (jumps >= 2) {
                value += 0.042;
            }

            if (jumps >= 3) {
                value += thirdvalue + 0.001;
            }
        }

        if (mc.thePlayer.moveForward <= 0) {
            value -= 0.06;
        }

        if (mc.thePlayer.isCollidedHorizontally) {
            value -= 0.1;
            aacCount = 0;
        }

        return value;
    }

    private double getHypixelSpeed(int stage) {
        double value = MoveUtils.defaultSpeed() + (0.028 * MoveUtils.getSpeedEffect())
                + (double) MoveUtils.getSpeedEffect() / 15;
        double firstvalue = 0.4145 + (double) MoveUtils.getSpeedEffect() / 12.5;
        double decr = (((double) stage / 500) * 2);

        if (stage == 0) {
            // JUMP
            if (timer.delay(300)) {
                timer.reset();
                // mc.timer.timerSpeed = 1.354f;
            }

            if (!lastCheck.delay(500)) {
                if (!shouldslow) {
                    shouldslow = true;
                }
            } else {
                if (shouldslow) {
                    shouldslow = false;
                }
            }

            value = 0.64 + (MoveUtils.getSpeedEffect() + (0.028 * MoveUtils.getSpeedEffect())) * 0.134;
        } else if (stage == 1) {
            /*
             * if (mc.timer.timerSpeed == 1.354f) { //mc.timer.timerSpeed = 1.254f; }
             */

            value = firstvalue;
        } else if (stage >= 2) {
            /*
             * if (mc.timer.timerSpeed == 1.254f) { //mc.timer.timerSpeed = 1f; }
             */

            value = firstvalue - decr;
        }

        if (shouldslow || !lastCheck.delay(500) || collided) {
            value = 0.2;

            if (stage == 0) {
                value = 0;
            }
        }

        return Math.max(value, shouldslow ? value : MoveUtils.defaultSpeed() + (0.028 * MoveUtils.getSpeedEffect()));
    }

    private void setMotion( double speed) {
        double forward = mc.thePlayer.movementInput.moveForward;
        double strafe = mc.thePlayer.movementInput.moveStrafe;
        float yaw = mc.thePlayer.rotationYaw;

        if ((forward == 0.0D) && (strafe == 0.0D)) {

            mc.thePlayer.motionX = 0;
            mc.thePlayer.motionZ = 0;

        } else {
            if (forward != 0.0D) {
                if (strafe > 0.0D) {
                    yaw += (forward > 0.0D ? -45 : 45);
                } else if (strafe < 0.0D) {
                    yaw += (forward > 0.0D ? 45 : -45);
                }

                strafe = 0.0D;

                if (forward > 0.0D) {
                    forward = 1;
                } else if (forward < 0.0D) {
                    forward = -1;
                }
            }
            mc.thePlayer.motionX = forward * speed * Math.cos(Math.toRadians(yaw + 90.0F))
                    + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F));
            mc.thePlayer.motionZ = forward * speed * Math.sin(Math.toRadians(yaw + 90.0F))
                    - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F));

        }
    }

}
