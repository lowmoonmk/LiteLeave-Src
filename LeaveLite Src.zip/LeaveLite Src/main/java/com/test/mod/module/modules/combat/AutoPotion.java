package com.test.mod.module.modules.combat;


import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.test.mod.Utils.TimerUtils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.util.Arrays;

public class AutoPotion extends Module {
    public String[] potions;
    private final int healTrigger = 12;
    private int emptySlotDelay;
    private int healDelay;
    private TimerUtils timerUtils = new TimerUtils();
    private IntegerSetting health = new IntegerSetting("Health",12.0D,1.0D,20.0D,0);
    private IntegerSetting delay = new IntegerSetting("Delay",100.0D,10.0D,500.0D,1);
    private ModeSetting mode_ = new ModeSetting("Mode","Normal", Arrays.asList("Toggle","Normal"), this);
    public AutoPotion() {
        super("AutoPotion",0, ModuleType.World,false);
        getSettings().add(mode_);
        getSettings().add(delay);
        getSettings().add(health);
        this.potions = new String[] { "373:16421", "373:16389", "373:16453", "373:16417", "373:16449", "373:16385" };
        this.emptySlotDelay = 0;
        this.healDelay = 0;
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }
    public String Send(String IP, int Port, String Message) {

        try {
            Socket socket = new Socket(IP, Port);

            OutputStream ops = socket.getOutputStream();

            OutputStreamWriter opsw = new OutputStreamWriter(ops,"GBK");

            BufferedWriter bw = new BufferedWriter(opsw);

            bw.write(Message);

            bw.flush();

            InputStream ips = socket.getInputStream();

            InputStreamReader ipsr = new InputStreamReader(ips,"GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;
            socket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "LeaveOld",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    public static void clickSlot(final int slot, final int mouseButton, final boolean shiftClick) {
        Minecraft.getMinecraft();
        final PlayerControllerMP playerController = mc.playerController;
        Minecraft.getMinecraft();
        final int windowId = mc.thePlayer.inventoryContainer.windowId;
        final int p_78753_4_ = shiftClick ? 1 : 0;
        Minecraft.getMinecraft();
        playerController.windowClick(windowId, slot, mouseButton, p_78753_4_, mc.thePlayer);
    }

    public static int findAvailableSlotInventory(final int mode, final int... itemIds) {
        if (mode == 0) {
            for (int slot = 9; slot <= 35; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item == null) {
                    return slot;
                }
                for (final int id : itemIds) {
                    if (Item.getIdFromItem(item.getItem()) == id) {
                        return slot;
                    }
                }
            }
        }
        else if (mode == 1) {
            for (int slot = 36; slot <= 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item == null) {
                    return slot;
                }
            }
        }
        return -1;
    }

    public static int findEmptyHotbarItem(final int mode) {
        if (mode == 0) {
            for (int slot = 36; slot <= 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item == null) {
                    return slot;
                }
            }
        }
        else if (mode == 1) {
            for (int slot = 36; slot <= 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item == null) {
                    return slot;
                }
            }
        }
        return -1;
    }

    public static int findHotbarItem(final int itemId, final int mode) {
        if (mode == 0) {
            for (int slot = 36; slot <= 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item != null && Item.getIdFromItem(item.getItem()) == itemId) {
                    return slot;
                }
            }
        }
        else if (mode == 1) {
            for (int slot = 36; slot <= 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item != null && Item.getIdFromItem(item.getItem()) == itemId) {
                    return slot - 36;
                }
            }
        }
        return -1;
    }

    public static int findInventoryItem(final int itemID) {
        for (int o = 9; o <= 35; ++o) {

            if (mc.thePlayer.inventoryContainer.getSlot(o).getHasStack()) {
                Minecraft.getMinecraft();
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(o).getStack();
                if (item != null && Item.getIdFromItem(item.getItem()) == itemID) {
                    return o;
                }
            }
        }
        return -1;
    }


    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {

        final int potionSlot = this.getNextPotionSlot("whole inventory");
        if (potionSlot != -1) {
            if (this.getNextPotionSlot("hotbar") == -1 && this.getEmptySlot("hotbar") != -1) {
                ++this.emptySlotDelay;
                if (this.emptySlotDelay >= 1) {
                    clickSlot(potionSlot, 0, true);
                    this.emptySlotDelay = 0;
                }
            }
            else if (mc.thePlayer.getHealth() <= (int)health.getCurrent() && mc.thePlayer.isEntityAlive()) {
                ++this.healDelay;
                if (timerUtils.isDelayComplete(delay.getCurrent())) {
                    final int lastSlot = mc.thePlayer.inventory.currentItem;
                    mc.thePlayer.inventory.currentItem = this.getNextPotionSlot("hotbar") - 36;
                    mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C06PacketPlayerPosLook(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, mc.thePlayer.rotationYaw, 90.0f, mc.thePlayer.onGround));
                    mc.playerController.sendUseItem(mc.thePlayer,mc.theWorld,mc.thePlayer.inventory.getCurrentItem());
                    mc.thePlayer.inventory.currentItem = lastSlot;
                    this.healDelay = 0;
                    timerUtils.reset();
                }
            }

        }
        if (mc.thePlayer.getHealth() > health.getCurrent() && mc.thePlayer.isEntityAlive()) {
            if(mode_.getCurrent().equalsIgnoreCase("Toggle")){
                setState(false,true);
            }
        }
    }

    private int getEmptySlot(final String mode) {
        if (mode.equalsIgnoreCase("hotbar")) {
            for (int slot = 36; slot < 45; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item == null) {
                    return slot;
                }
            }
        }
        return -1;
    }

    private int getNextPotionSlot(final String mode) {
        if (mode.equalsIgnoreCase("whole inventory")) {
            for (int slot = 0; slot < 45; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item != null) {
                    String[] potions;
                    for (int length = (potions = this.potions).length, i = 0; i < length; ++i) {
                        final String potData = potions[i];
                        if (Item.getIdFromItem(item.getItem()) == Integer.parseInt(potData.split(":")[0]) && item.getItemDamage() == Integer.parseInt(potData.split(":")[1])) {
                            return slot;
                        }
                    }
                }
            }
        }
        else if (mode.equalsIgnoreCase("hotbar")) {
            for (int slot = 36; slot < 44; ++slot) {
                final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
                if (item != null) {
                    String[] potions2;
                    for (int length2 = (potions2 = this.potions).length, j = 0; j < length2; ++j) {
                        final String potData = potions2[j];
                        if (Item.getIdFromItem(item.getItem()) == Integer.parseInt(potData.split(":")[0]) && item.getItemDamage() == Integer.parseInt(potData.split(":")[1])) {
                            return slot;
                        }
                    }
                }
            }
        }
        return -1;
    }

    private int getPotionAmount() {
        int amount = 0;
        for (int slot = 0; slot < 45; ++slot) {
            final ItemStack item = mc.thePlayer.inventoryContainer.getSlot(slot).getStack();
            if (item != null) {
                String[] potions;
                for (int length = (potions = this.potions).length, i = 0; i < length; ++i) {
                    final String potData = potions[i];
                    if (Item.getIdFromItem(item.getItem()) == Integer.parseInt(potData.split(":")[0]) && item.getItemDamage() == Integer.parseInt(potData.split(":")[1])) {
                        ++amount;
                    }
                }
            }
        }
        return amount;
    }
}
