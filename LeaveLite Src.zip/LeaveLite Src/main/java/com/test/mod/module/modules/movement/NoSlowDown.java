package com.test.mod.module.modules.movement;


import com.test.mod.Utils.NoSlowDownUtil;
import com.test.mod.Utils.TimerUtils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.item.ItemSword;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovementInput;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.Arrays;

public class NoSlowDown extends Module {
    MovementInput origmi;
    TimerUtils timer = new TimerUtils();
    private final ModeSetting Mode = new ModeSetting("Mode","Vanilla", Arrays.asList("Basic","Vanilla","NCP","AAC5","AAC","Custom"),this);
   //private final EnableSetting sendPacket = new EnableSetting("SendPacket")
    private IntegerSetting percent = new IntegerSetting("percent",0.0D,0.0D,100.0d,1);
    public NoSlowDown() {
        super("NoSlowDown", Keyboard.KEY_NONE, ModuleType.Movement,false);
        getSettings().add(Mode);
    }

    @Override
    public void onEnable() {
        origmi=mc.thePlayer.movementInput;
        if(!(mc.thePlayer.movementInput instanceof NoSlowDownUtil)) {
            mc.thePlayer.movementInput = new NoSlowDownUtil(mc.gameSettings);
        }
        super.onEnable();
    }

    public static boolean isOnGround(double height)
    {
        if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, mc.thePlayer.getEntityBoundingBox().offset(0.0D, -height, 0.0D)).isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    @SubscribeEvent
    public void onPlayerTicks(TickEvent.PlayerTickEvent event) {
        if (Mode.getCurrent().equalsIgnoreCase("AAC")) {
            if (mc.thePlayer.isBlocking() && !mc.thePlayer.isRiding()
                    && isMoving()) {
                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
                        new BlockPos(0, 0, 0), EnumFacing.DOWN));
            }
        } else if (Mode.getCurrent().equalsIgnoreCase("Hypixel")) {

            if (mc.thePlayer.isBlocking() && isMoving() && isOnGround(0.42)) {

                mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(
                        C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));

            }
        }else if(Mode.getCurrent().equalsIgnoreCase("AAC5")){
            if (mc.thePlayer.isUsingItem() || mc.thePlayer.isBlocking()) {
                BlockPos pos = new BlockPos(-1, -1, -1);
               sendPacket(new C08PacketPlayerBlockPlacement(pos, 255,
                        mc.thePlayer.inventory.getCurrentItem(), 0f, 0f, 0f));
            }
        }
    }

    @Override
    public void onDisable() {
        if (Mode.getCurrent().equalsIgnoreCase("Basic")) {
            if (!(mc.thePlayer.movementInput instanceof NoSlowDownUtil)) {
                mc.thePlayer.movementInput = new NoSlowDownUtil(mc.gameSettings);
            }
            NoSlowDownUtil move = (NoSlowDownUtil) mc.thePlayer.movementInput;
            move.setNSD(false);
        }
        mc.thePlayer.movementInput=origmi;
        super.onDisable();
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if(!(mc.thePlayer.movementInput instanceof NoSlowDownUtil)) {
            origmi=mc.thePlayer.movementInput;
            mc.thePlayer.movementInput = new NoSlowDownUtil(mc.gameSettings);
        }

        //vanilla
        if(mc.thePlayer.onGround&&!mc.gameSettings.keyBindJump.isKeyDown() || mc.gameSettings.keyBindSneak.isKeyDown()&&mc.gameSettings.keyBindUseItem.isKeyDown()) {
            NoSlowDownUtil move = (NoSlowDownUtil) mc.thePlayer.movementInput;
            move.setNSD(true);
        }

        if(mc.thePlayer.isUsingItem() && isMoving() && isOnGround(0.42) && Mode.getCurrent().equalsIgnoreCase("NCP")){

            double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
            mc.thePlayer.sendQueue.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        }

        if (Mode.getCurrent().equalsIgnoreCase("Custom")) {
            try{

                if(mc.thePlayer.getItemInUse().getItem() instanceof ItemSword) {
                    mc.thePlayer.motionX *= 0.5f;
                    mc.thePlayer.motionZ *= 0.5f;
                }
                if (mc.thePlayer.isUsingItem()) {
                    mc.thePlayer.motionX *= percent.getCurrent() / 100;
                    mc.thePlayer.motionZ *= percent.getCurrent()/ 100;
                }
            }  catch (NullPointerException ignore){}
        }

        //post
        if(mc.thePlayer.isUsingItem() && isMoving() && isOnGround(0.42)&& Mode.getCurrent().equalsIgnoreCase("NCP")){
            double x = mc.thePlayer.posX; double y = mc.thePlayer.posY; double z = mc.thePlayer.posZ;
            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
        }



        if (Mode.getCurrent().equalsIgnoreCase("Basic")) {
            if (mc.thePlayer.onGround && !mc.gameSettings.keyBindJump.isKeyDown()
                    || mc.gameSettings.keyBindSneak.isKeyDown() && mc.gameSettings.keyBindUseItem.isKeyDown()) {
                if (!(mc.thePlayer.movementInput instanceof NoSlowDownUtil)) {
                    mc.thePlayer.movementInput = new NoSlowDownUtil(mc.gameSettings);
                }
                NoSlowDownUtil move = (NoSlowDownUtil) mc.thePlayer.movementInput;
                move.setNSD(true);

                if (event.phase == TickEvent.Phase.START) {
                    if (mc.thePlayer.isBlocking() && !mc.thePlayer.isRiding()
                            && isMoving()) {
                                sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                        new BlockPos(0, 0, 0), EnumFacing.DOWN));
                    }
                } else if (event.phase == TickEvent.Phase.END) {
                    if (mc.thePlayer.isBlocking() && !mc.thePlayer.isRiding()
                            && isMoving()) {
                        sendPacket(new C08PacketPlayerBlockPlacement(
                              mc.thePlayer.inventory.getCurrentItem()));
                    }
                }
            }

           // if (!sendpacket.getValue()) {
          //      return;
           // }
            if (Mode.getCurrent().equalsIgnoreCase("AAC")) {

                if (mc.thePlayer.isBlocking() && !mc.thePlayer.isRiding()
                        && isMoving()) {

                    if (event.phase == TickEvent.Phase.START) {
                        if (mc.thePlayer.onGround || isOnGround(0.5)) {
                          sendPacket(
                                    new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM,
                                            new BlockPos(0, 0, 0), EnumFacing.DOWN));
                        }
                    } else if (event.phase == TickEvent.Phase.END) {
                        if (timer.isDelayComplete(65.0D)) {

                            sendPacket(new C08PacketPlayerBlockPlacement(
                                    mc.thePlayer.inventory.getCurrentItem()));
                            timer.reset();
                        }
                    }
                }
            }
        }
    }
    public static boolean isMoving() {
        if ((!mc.thePlayer.isCollidedHorizontally) && (!mc.thePlayer.isSneaking())) {
            return ((mc.thePlayer.movementInput.moveForward != 0.0F || mc.thePlayer.movementInput.moveStrafe != 0.0F));
        }
        return false;
    }
    public void sendPacket(Packet packet) {
        mc.thePlayer.sendQueue.addToSendQueue(packet);
    }

}
