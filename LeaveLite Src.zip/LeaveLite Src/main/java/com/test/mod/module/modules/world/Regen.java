package com.test.mod.module.modules.world;//package i.gishreloaded.gishcode.hack.hacks;

import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

public class Regen extends Module {

	public IntegerSetting health = new IntegerSetting("Health", 16D, 4D, 20D,0);
	public IntegerSetting speed = new IntegerSetting("Speed", 100D, 10D, 1000D,0);

	public Regen() {
		super("Regen",0, ModuleType.Combat,false);

		this.add(health,speed);
	}

	@SubscribeEvent
	public void onClientTick(ClientTickEvent event) {
		if (mc.thePlayer.capabilities.isCreativeMode || mc.thePlayer.getHealth() == 0)
			return;

		if (mc.thePlayer.getFoodStats().getFoodLevel() < 18)
			return;

		if (mc.thePlayer.getHealth() >= mc.thePlayer.getMaxHealth())
			return;

		if (mc.thePlayer.getHealth() <= health.getCurrent()) {
			for (int i = 0; i < (int)speed.getCurrent(); ++i)
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer());
			
		}
	}
}
