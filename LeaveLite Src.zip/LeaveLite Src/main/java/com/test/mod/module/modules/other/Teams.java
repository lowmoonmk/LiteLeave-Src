package com.test.mod.module.modules.other;

import com.test.mod.Client;
import com.test.mod.Utils.Utils;
import com.test.mod.command.commands.SetTeamSign;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.ModeSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import sun.security.pkcs11.Secmod;

import java.util.Arrays;
import java.util.Collection;

public class Teams extends Module {
    public ModeSetting mode = new ModeSetting("Mode","ArmorColor", Arrays.asList("Base","ArmorColor","NameColor","TabList"),this);
    public Teams() {
        super("Teams",0, ModuleType.Other,false);
        add(mode);
    }
    public static boolean isTeam(EntityLivingBase entity) {
        Module teams = Client.instance.moduleManager.getModule("Teams");
        if(teams.isState()) {
            if(entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                if(teams.isToggledMode("Base")) {
                    if(player.getTeam() != null && mc.thePlayer.getTeam() != null) {
                        if(player.getTeam().isSameTeam(mc.thePlayer.getTeam())){
                            return false;
                        }
                    }
                }
                if(teams.isToggledMode("ArmorColor")) {
                    if(!Utils.checkEnemyColor(player)) {
                        return false;
                    }
                }
                if(teams.isToggledMode("NameColor")) {
                    if(!Utils.checkEnemyNameColor(player)) {
                        return false;
                    }
                }
                if (teams.isToggledMode("TabList")){

                    Collection<NetworkPlayerInfo> list = mc.thePlayer.sendQueue.getPlayerInfoMap();
                    for (NetworkPlayerInfo networkplayerinfo : list)
                    {;
                        if (entity.getName().equals(Minecraft.getMinecraft().ingameGUI.getTabList().getPlayerName(networkplayerinfo))){
                            if (!mc.ingameGUI.getTabList().getPlayerName(networkplayerinfo).contains(SetTeamSign.teamsign)){
                                return false;
                            }else{
                                return true;
                            }
                        }
                    }

                }
            }
        }
        return true;
    }
    public static boolean isTeam(Entity entity) {
        Module teams = Client.instance.moduleManager.getModule("Teams");
        if(teams.isState()) {
            if(entity instanceof EntityPlayer) {
                EntityPlayer player = (EntityPlayer) entity;
                if(teams.isToggledMode("Base")) {
                    if(player.getTeam() != null && mc.thePlayer.getTeam() != null) {
                        if(player.getTeam().isSameTeam(mc.thePlayer.getTeam())){
                            return false;
                        }
                    }
                }
                if(teams.isToggledMode("ArmorColor")) {
                    if(!Utils.checkEnemyColor(player)) {
                        return false;
                    }
                }
                if(teams.isToggledMode("NameColor")) {
                    if(!Utils.checkEnemyNameColor(player)) {
                        return false;
                    }
                }
                if (teams.isToggledMode("TabList")){

                    Collection<NetworkPlayerInfo> list = mc.thePlayer.sendQueue.getPlayerInfoMap();
                    for (NetworkPlayerInfo networkplayerinfo : list)
                    {;
                        if (entity.getName().equals(Minecraft.getMinecraft().ingameGUI.getTabList().getPlayerName(networkplayerinfo))){
                            if (!mc.ingameGUI.getTabList().getPlayerName(networkplayerinfo).contains(SetTeamSign.teamsign)){
                                return false;
                            }else{
                                return true;
                            }
                        }
                    }

                }
            }
        }
        return true;
    }
}
