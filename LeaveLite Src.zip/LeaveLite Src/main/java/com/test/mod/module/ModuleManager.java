package com.test.mod.module;

import com.test.mod.module.modules.combat.*;
import com.test.mod.module.modules.movement.*;
import com.test.mod.module.modules.other.AntiAFK;
import com.test.mod.module.modules.other.Command;
import com.test.mod.module.modules.other.Teams;
import com.test.mod.module.modules.render.*;
import com.test.mod.module.modules.world.*;

import java.util.ArrayList;

public class ModuleManager {
    private ArrayList<Module> modules = new ArrayList<Module>();
    public ArrayList<Module> getModules(){
        return modules;
    }
    public Module getModule(String name){
        for(Module module : modules){
            if(module.getName().equals(name)){
                return module;
            }
        }
        return null;
    }
    public void add(Module... modules) {
        for (Module module : modules) {
            this.modules.add(module);
        }
    }
    public void loadModules(){
        add(new Sprint(),new Command(),new Reach(),new ESP(),new Chams(),new AutoClicker(),new FullBright(),new ItemESP(),new Nametags(),
                new Projectiles(),new Xray(),new Hud(),new FastPlace(),new Scaffold(),new AutoPotion(),new Fly(),new AutoTool(),
                new AntiAFK(),new InvMove(),new ChestStealer(),new Velocity(),new NoSlowDown(),new BlockESP(),new FuckBed(),
                new Criticals(),new SpeedMine(),new HitBox(),new AimBot(),new Regen(),new SuperKnockback(),new NoFall(),
                new Speed(),new Teams());
    }

}
