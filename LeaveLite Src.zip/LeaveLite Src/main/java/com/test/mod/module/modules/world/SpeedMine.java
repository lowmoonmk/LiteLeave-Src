package com.test.mod.module.modules.world;

import com.test.mod.Client;
import com.test.mod.Utils.Connection;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;

public class SpeedMine extends Module {
    public BlockPos blockPos;
    public EnumFacing facing;
    public C07PacketPlayerDigging curPacket;
    private boolean bzs = false;
    private float bzx = 0.0f;
    private EnableSetting RangeBreak=new EnableSetting("RangeBreak",false);
    private EnableSetting C03=new EnableSetting("Packet",false);
    private EnableSetting pot=new EnableSetting("Pot",false);
    private EnableSetting ultraBoost=new EnableSetting("UltraBoost",false);
    private EnableSetting Reflection=new EnableSetting("Reflection",false);
    public SpeedMine() {
        super("SpeedMine",0, ModuleType.World,false);
        getSettings().add(C03);
        getSettings().add(pot);
        getSettings().add(ultraBoost);
        getSettings().add(Reflection);
        getSettings().add(RangeBreak);
    }

    @Override
    public boolean onPacket(Object packet, Connection.Side side) {


        if (Reflection.getEnable()){
            if(!mc.playerController.isInCreativeMode()) {
                Field field = ReflectionHelper.findField(PlayerControllerMP.class,new String[] { "curBlockDamageMP", "field_78770_f" });
                Field blockdelay = ReflectionHelper.findField(PlayerControllerMP.class,new String[] { "blockHitDelay", "field_78781_i" });
                //mc.playerController.blockHitDelay = 0;
                try {
                    if (!field.isAccessible()) {
                        field.setAccessible(true);
                    }
                    if (!blockdelay.isAccessible()) {
                        blockdelay.setAccessible(true);
                    }

                    blockdelay.setInt(mc.playerController, 0);
                    if (field.getFloat(mc.playerController) >= 0.7F)
                    {
                        field.setFloat(mc.playerController, 1F);
                    }
                } catch (Exception e) {

                }
            }
        }else{
            try{
                if (packet instanceof C07PacketPlayerDigging && packet != curPacket && !mc.playerController.extendedReach() && mc.playerController != null) {

                    if (packet instanceof C07PacketPlayerDigging){
                        C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging)packet;
                        if (RangeBreak.getEnable()){
                            if (c07PacketPlayerDigging.getFacing() == EnumFacing.DOWN || c07PacketPlayerDigging.getFacing() == EnumFacing.UP){
                                BlockPos BP1 = new BlockPos(c07PacketPlayerDigging.getPosition().getX()+1,c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP1);
                                BlockPos BP2 = new BlockPos(c07PacketPlayerDigging.getPosition().getX()-1,c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP2);
                                BlockPos BP3 = new BlockPos(c07PacketPlayerDigging.getPosition().getX(),c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ()+1);
                                breakblock(BP3);
                                BlockPos BP4 = new BlockPos(c07PacketPlayerDigging.getPosition().getX(),c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ()-1);
                                breakblock(BP4);

                            }else{
                                BlockPos BP1 = new BlockPos(c07PacketPlayerDigging.getPosition().getX()+1,c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP1);
                                BlockPos BP2 = new BlockPos(c07PacketPlayerDigging.getPosition().getX()-1,c07PacketPlayerDigging.getPosition().getY(), c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP2);
                                BlockPos BP3 = new BlockPos(c07PacketPlayerDigging.getPosition().getX(),c07PacketPlayerDigging.getPosition().getY()+1, c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP3);
                                BlockPos BP4 = new BlockPos(c07PacketPlayerDigging.getPosition().getX(),c07PacketPlayerDigging.getPosition().getY()-1, c07PacketPlayerDigging.getPosition().getZ());
                                breakblock(BP4);
                            }
                        }
                    }

                    C07PacketPlayerDigging c07PacketPlayerDigging = (C07PacketPlayerDigging)packet;

                    if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.START_DESTROY_BLOCK) {
                        this.bzs = true;
                        this.blockPos = c07PacketPlayerDigging.getPosition();
                        this.facing = c07PacketPlayerDigging.getFacing();

                        this.bzx = 0.0f;
                        onBreak(blockPos,facing);

                    } else if (c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK || c07PacketPlayerDigging.getStatus() == C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK) {
                        this.bzs = false;
                        this.blockPos = null;
                        this.facing = null;
                        onBreak(blockPos,facing);
                    }




                }

            }catch (Exception ignore){

            }
        }
        return true;
    }
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        try{
            if (pot.getEnable()) {
                mc.thePlayer.addPotionEffect(new PotionEffect(Potion.digSpeed.getId(), 100, 1));

            }



            if (mc.playerController.extendedReach()) {
                setBlockHitDelay(mc,0);
                if (getCurBlockDamageMP(mc) >= 0.6F) {
                    setCurBlockDamageMP(mc,1.0F);
                }

            } else if (this.bzs) {
                Block block = mc.theWorld.getBlockState(this.blockPos).getBlock();
                this.bzx += block.getPlayerRelativeBlockHardness(mc.thePlayer, mc.theWorld, this.blockPos) * 1.4;
                if (this.bzx >= 1.0f) {
                    mc.theWorld.setBlockState(this.blockPos, Blocks.air.getDefaultState(), 11);
                    C07PacketPlayerDigging packet = new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, this.blockPos, this.facing);
                    curPacket = packet;
                    if (C03.getEnable()) {
                        new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ, true);
                    }
                    mc.thePlayer.sendQueue.getNetworkManager().sendPacket(packet);

                    this.bzx = 0.0f;
                    this.bzs = false;
                }
            }}catch (Exception ignore){}
    }
    private void breakblock(BlockPos newBP){
        MinecraftServer server = MinecraftServer.getServer();
        EntityPlayerMP playerEntity = server.getConfigurationManager().getPlayerByUsername(mc.thePlayer.getName());
        playerEntity.theItemInWorldManager.onBlockClicked(newBP, EnumFacing.DOWN);
        mc.thePlayer.swingItem();
        playerEntity.theItemInWorldManager.blockRemoving(newBP);
    }
    private boolean canBreak(BlockPos pos) {
        try{
            final IBlockState blockState = mc.theWorld.getBlockState(pos);
            final Block block = blockState.getBlock();
            return block.getBlockHardness(mc.theWorld, pos) != -1;
        }catch (Exception ignore){}
        return true;

    }

    public boolean packet = true;
    public boolean damage = true;
    public static void setBlockHitDelay(Minecraft mc, int delay){
        try {
            Field m = PlayerControllerMP.class.getDeclaredField(Client.isObfuscate?"field_78781_i":"blockHitDelay");
            m.setAccessible(true);
            m.set(mc.playerController,delay);
            m.setAccessible(false);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public static float getCurBlockDamageMP(Minecraft mc){
        try {
            float curv;
            Field m = PlayerControllerMP.class.getDeclaredField(Client.isObfuscate ?"field_78770_f":"curBlockDamageMP");
            m.setAccessible(true);
            curv= (float) m.get(mc.playerController);
            m.setAccessible(false);
            return curv;
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
        return 0f;
    }
    public static void setCurBlockDamageMP(Minecraft mc,float damage){
        try {
            float curv;
            Field m = PlayerControllerMP.class.getDeclaredField(Client.isObfuscate ?"field_78770_f":"curBlockDamageMP");
            m.setAccessible(true);
            m.set(mc.playerController,damage);
            m.setAccessible(false);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            e.printStackTrace();
        }
    }
    public void onBreak(BlockPos pos,EnumFacing facing) {
        try{
            if (canBreak(pos)) {
                if (ultraBoost.getEnable()) {
                    mc.thePlayer.swingItem();
                    mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK ,pos, facing));
                    mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, pos, facing));
                }
                if (ultraBoost.getEnable()) {
                    setBlockHitDelay(mc,0);
                    if (getCurBlockDamageMP(mc) >= 0.7F) {
                        setCurBlockDamageMP(mc,1.0F);
                    }
                }
            }
        }catch (Exception ignore){}
    }



}
