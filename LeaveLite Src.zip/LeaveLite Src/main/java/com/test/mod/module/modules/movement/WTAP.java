package com.test.mod.module.modules.movement;

import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.HashMap;
import java.util.concurrent.ThreadLocalRandom;

public class WTAP extends Module {
    public static double comboLasts;
    private static final HashMap<EntityPlayer, Long> newEnt = new HashMap<EntityPlayer, Long>();
    public static boolean comboing, hitCoolDown, alreadyHit;
    public static int hitTimeout, hitsWaited;
    private EnableSetting onlyPlayers = new EnableSetting("PlayersOnly",true);
    private IntegerSetting minActionTicks = new IntegerSetting("Delay",5.0D,1.0D,100.0d,1);
    private IntegerSetting minOnceEvery = new IntegerSetting("Hits",1.0D,1.0D,10.0d,1);
    private IntegerSetting range = new IntegerSetting("Range",3.0D,3.0D,6.0d,1);
    public WTAP() {
        super("WTAP",0, ModuleType.Movement,false);
        getSettings().add(onlyPlayers);
        getSettings().add(minActionTicks);
        getSettings().add(minOnceEvery);
        getSettings().add(range);

    }
    @SubscribeEvent
    public void onEntityJoinWorld(EntityJoinWorldEvent event) {
        if(!Tools.isPlayerInGame()) return;
        if (true && event.entity instanceof EntityPlayer && event.entity != mc.thePlayer) {
            newEnt.put((EntityPlayer)event.entity, System.currentTimeMillis());
        }

    }

    @SubscribeEvent
    public void onTick(TickEvent.RenderTickEvent e) {
        if (Tools.nullCheck())
            return;
        if(!Tools.isPlayerInGame())
            return;

        if(comboing) {
            if(System.currentTimeMillis() >= comboLasts){
                comboing = false;
                finishCombo();
                return;
            }else {
                return;
            }
        }



        if (mc.objectMouseOver != null && mc.objectMouseOver.entityHit instanceof Entity && Mouse.isButtonDown(0)) {
            Entity target = mc.objectMouseOver.entityHit;
            //////////System.out.println(target.hurtResistantTime);
            if(target.isDead) {
                return;
            }

            if (mc.thePlayer.getDistanceToEntity(target) <= range.getCurrent()) {
                if (target.hurtResistantTime >= 10) {

                    if (onlyPlayers.getEnable()){
                        if (!(target instanceof EntityPlayer)){
                            return;
                        }
                    }

                    if (hitCoolDown && !alreadyHit) {
                        //////////System.out.println("coolDownCheck");
                        hitsWaited++;
                        if(hitsWaited >= hitTimeout){
                            //////////System.out.println("hiit cool down reached");
                            hitCoolDown = false;
                            hitsWaited = 0;
                        } else {
                            //////////System.out.println("still waiting for cooldown");
                            alreadyHit = true;
                            return;
                        }
                    }

                    //////////System.out.println("Continued");

                    if(!alreadyHit){
                        //////////System.out.println("Startring combo code");

                            hitTimeout =  (int)minOnceEvery.getCurrent();
                        } else {

                            hitTimeout = ThreadLocalRandom.current().nextInt((int)minOnceEvery.getCurrent(), (int)minOnceEvery.getCurrent());
                        }
                        hitCoolDown = true;
                        hitsWaited = 0;

                        comboLasts = ThreadLocalRandom.current().nextDouble(minActionTicks.getCurrent(),  minActionTicks.getCurrent()+0.01) + System.currentTimeMillis();
                        comboing = true;
                        startCombo();
                        //////////System.out.println("Combo started");
                        alreadyHit = true;
                    }
                } else {
                    if(alreadyHit){
                        //////////System.out.println("UnHit");
                    }
                    alreadyHit = false;
                    //////////System.out.println("REEEEEEE");
                }
            }
        }


    private static void finishCombo() {
        if(Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())){
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), true);
        }
    }

    private static void startCombo() {
        if(Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode())) {
            KeyBinding.setKeyBindState(mc.gameSettings.keyBindForward.getKeyCode(), false);
            KeyBinding.onTick(mc.gameSettings.keyBindForward.getKeyCode());
        }
    }
}
