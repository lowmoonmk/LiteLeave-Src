package com.test.mod.module.modules.world;


import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.lang.reflect.Field;

public class FastPlace extends Module {
    //public static  r = null;
    Field c=null;
    public Minecraft mc = Minecraft.getMinecraft();
    private IntegerSetting Dalay = new IntegerSetting("Dalay",0.0D,0.0D,4.0d,0);
    public FastPlace() {
        super("FastPlace", Keyboard.KEY_NONE, ModuleType.World,false);
        getSettings().add(Dalay);
    }

    @Override
    public void onEnable(){
        try {
             c= mc.getClass().getDeclaredField("field_71467_ac");
        }
        catch (Exception d) {
            try {
                c = mc.getClass().getDeclaredField("rightClickDelayTimer");
            }
            catch (Exception f) {
            }
        }
        if (c != null) {
            c.setAccessible(true);
        }
    }
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if(!Tools.isPlayerInGame())
            return;

        if (e.phase == TickEvent.Phase.END) {
            if (Tools.isPlayerInGame() && mc.inGameHasFocus && c != null) {
                    ItemStack item = mc.thePlayer.getHeldItem();
                    if (item == null || !(item.getItem() instanceof ItemBlock)) {
                        return;
                    }


                try {
                    int c1 = (int)Dalay.getCurrent();
                    if (c1 == 0) {
                        c.set(mc, 0);
                    }else {
                        if (c1 == 4) {
                            return;
                        }
                        int d = c.getInt(mc);
                        if (d == 4) {
                            c.set(mc, c1);
                        }
                    }
                } catch (IllegalAccessException var4) {
                }

            }

        }
    }

}
