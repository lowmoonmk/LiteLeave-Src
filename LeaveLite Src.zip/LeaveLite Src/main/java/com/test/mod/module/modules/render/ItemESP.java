package com.test.mod.module.modules.render;

import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.util.Iterator;
import java.util.List;

public class ItemESP extends Module {
   public ItemESP() {
        super("ItemESP", Keyboard.KEY_NONE, ModuleType.Render,false);
    }

    public static List getEntityList() {
        return mc.theWorld.getLoadedEntityList();
    }
    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        RenderHelper.enableGUIStandardItemLighting();
        Iterator iterator = getEntityList().iterator();

        while (iterator.hasNext()) {
            Object object = iterator.next();

            if (object instanceof EntityItem || object instanceof EntityArrow) {
                Entity entity = (Entity) object;

                drawESP(entity, 255,255,255, 1.0F, event.partialTicks);
            }
        }
        RenderHelper.disableStandardItemLighting();

    }
    public static void drawESP(Entity entity, float colorRed, float colorGreen, float colorBlue, float colorAlpha, float ticks) {
        try {
            double exception =mc.getRenderManager().viewerPosX;
            double renderPosY =mc.getRenderManager().viewerPosY;
            double renderPosZ =mc.getRenderManager().viewerPosZ;
            double xPos = entity.lastTickPosX + (entity.posX - entity.lastTickPosX) * (double) ticks - exception;
            double yPos = entity.lastTickPosY + (entity.posY - entity.lastTickPosY) * (double) ticks + (double) (entity.height / 2.0F) - renderPosY;
            double zPos = entity.lastTickPosZ + (entity.posZ - entity.lastTickPosZ) * (double) ticks - renderPosZ;
            float playerViewY =mc.getRenderManager().playerViewY;
            float playerViewX =mc.getRenderManager().playerViewX;
            boolean thirdPersonView =mc.getRenderManager().options.thirdPersonView == 2;

            GL11.glPushMatrix();
            GlStateManager.translate(xPos, yPos, zPos);
            GlStateManager.rotate(-playerViewY, 0.0F, 1.0F, 0.0F);
            GlStateManager.rotate((float) (thirdPersonView ? -1 : 1) * playerViewX, 1.0F, 0.0F, 0.0F);
            GL11.glEnable(3042);
            GL11.glDisable(3553);
            GL11.glDisable(2896);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glLineWidth(1.0F);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(2848);
            GL11.glColor4f(colorRed, colorGreen, colorBlue, colorAlpha);
            GL11.glBegin(1);
            GL11.glVertex3d(0.0D, 1.0D, 0.0D);
            GL11.glVertex3d(-0.5D, 0.5D, 0.0D);
            GL11.glVertex3d(0.0D, 1.0D, 0.0D);
            GL11.glVertex3d(0.5D, 0.5D, 0.0D);
            GL11.glVertex3d(0.0D, 0.0D, 0.0D);
            GL11.glVertex3d(-0.5D, 0.5D, 0.0D);
            GL11.glVertex3d(0.0D, 0.0D, 0.0D);
            GL11.glVertex3d(0.5D, 0.5D, 0.0D);
            GL11.glEnd();
            GL11.glDepthMask(true);
            GL11.glEnable(2929);
            GL11.glEnable(3553);
            GL11.glEnable(2896);
            GL11.glDisable(2848);
            GL11.glDisable(3042);
            GL11.glPopMatrix();
        } catch (Exception exception) {
            exception.printStackTrace();
        }

    }
}
