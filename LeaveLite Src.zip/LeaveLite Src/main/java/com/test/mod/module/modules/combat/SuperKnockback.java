package com.test.mod.module.modules.combat;

import com.test.mod.Utils.TimerUtils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.util.Arrays;

public class SuperKnockback extends Module {
    public ModeSetting mode = new ModeSetting("Mode", "Packet", Arrays.asList("ExtraPacket", "WTap", "Packet"), this);
    private IntegerSetting delayValue = new IntegerSetting("Delay", 0D, 0D, 500D, 1);
    private IntegerSetting hurtTimeValue = new IntegerSetting("HurtTime", 10D, 0D, 10D, 1);

    public SuperKnockback() {
        super("SuperKnockBack", 0, ModuleType.Combat, false);
        add(mode, delayValue, hurtTimeValue);
    }

    TimerUtils timerUtils = new TimerUtils();

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @SubscribeEvent
    public void onAttackEntity(AttackEntityEvent event) {
        if (event.target instanceof EntityLivingBase) {
            if (((EntityLivingBase) event.target).hurtTime > hurtTimeValue.getCurrent() || !timerUtils.isDelay((long) delayValue.getCurrent())) {
                return;
            }

            switch (mode.getCurrent().toLowerCase()) {
                case "extrapacket": {
                    if (mc.thePlayer.isSprinting()) {
                        mc.thePlayer.setSprinting(true);
                    }
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                }

                case "wtap": {
                    if (mc.thePlayer.isSprinting()) {
                        mc.thePlayer.setSprinting(false);
                    }
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                }
                case "packet": {
                    if (mc.thePlayer.isSprinting()) {
                        mc.thePlayer.setSprinting(true);
                    }
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                    mc.getNetHandler().addToSendQueue(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                }
            }
            timerUtils.reset();
        }
    }
}
