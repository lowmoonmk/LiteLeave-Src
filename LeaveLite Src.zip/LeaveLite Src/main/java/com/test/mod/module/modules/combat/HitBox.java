package com.test.mod.module.modules.combat;


import com.test.mod.Client;
import com.test.mod.Utils.EntitySize;
import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.module.modules.other.Teams;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.lang.reflect.Field;
import java.util.List;
public class HitBox extends Module {
    private static MovingObjectPosition mv;
    private static boolean showHitBox=true;
    private static Field timerField = null;
    private double ssiz;
    private static IntegerSetting Multiplier = new IntegerSetting("Multiplier",1.2D,1.0D,6.0d,1);
    public HitBox() {
        super("HitBox", Keyboard.KEY_NONE, ModuleType.Combat,false);
        getSettings().add(Multiplier);
    }
    public boolean check(EntityLivingBase entity) {
        if (entity instanceof EntityArmorStand) {
            return false;
        }
        // if (entity instanceof EntityPlayer) {
        // return false;
        //}
        if (entity == mc.thePlayer) {
            return false;
        }
        if (entity.isDead) {
            return false;
        }
        if (!entity.canBeCollidedWith()) {
            return false;
        }
        if(!Teams.isTeam(entity)) { return false; }
        return true;

    }

    @Override
    public void onEnable() {

        super.onEnable();
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (Tools.nullCheck())return;
        for (Object object :mc.theWorld.getLoadedEntityList()) {
            if (!(object instanceof EntityLivingBase))
                continue;
            EntityLivingBase entity = (EntityLivingBase) object;
            if (!check(entity)) {
                setEntityBoundingBoxSize(entity);
                continue;
            }
            if (entity instanceof EntityAnimal){
                setEntityBoundingBoxSize(entity, (float) (Multiplier.getCurrent()*1.1),
                        (float) (Multiplier.getCurrent()));
            }else {
                setEntityBoundingBoxSize(entity, (float) (Multiplier.getCurrent()),
                        (float) (Multiplier.getCurrent()*2));
            }

        }
    }

    @SubscribeEvent
    public void onMouse(MouseEvent event) {
        if (Tools.nullCheck())return;
        if (event.button == 0 && event.buttonstate && mv != null) {
            mc.objectMouseOver = mv;
        }
    }
    /*
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if(mc.thePlayer==null || mc.theWorld==null){
            return;
        }
        for(EntityPlayer player : getPlayersList()) {
            if(!check(player)) continue;
            double width =this.Multiplier.getCurrent() ;
            double height = this.Multiplier.getCurrent();
            setEntityBoundingBoxSize(player, width, height);
        }
    }

     */

    @Override
    public void onDisable() {
        if (Tools.nullCheck())return;
        for(Entity entity : getPlayersList())
            setEntityBoundingBoxSize(entity);
    }


    public static void setEntityBoundingBoxSize(Entity entity, float width, float height) {
        if (entity.width == width && entity.height == height)
            return;
        entity.width = width;
        entity.height = height;
        double d0 = (double) width / 2.0D;
        entity.setEntityBoundingBox(new AxisAlignedBB(entity.posX - d0, entity.posY, entity.posZ - d0, entity.posX + d0,
                entity.posY + (double) entity.height, entity.posZ + d0));

    }

    public static void setEntityBoundingBoxSize(Entity entity) {
        EntitySize size = getEntitySize(entity);
        entity.width = size.width;
        entity.height = size.height;
        double d0 = (double) (entity.width) / 2.0D;
        entity.setEntityBoundingBox(new AxisAlignedBB(entity.posX - d0, entity.posY, entity.posZ - d0, entity.posX + d0,
                entity.posY + (double) entity.height, entity.posZ + d0));
    }
    public static EntitySize getEntitySize(Entity entity) {
        EntitySize entitySize = new EntitySize(0.6F, 1.8F);
        return entitySize;
    }
    public static List<Entity> getPlayersList() {
        return mc.theWorld.loadedEntityList;
    }


}


