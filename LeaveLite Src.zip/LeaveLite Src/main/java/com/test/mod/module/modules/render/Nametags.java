/*
 * Decompiled with CFR 0.151.
 * 
 * Could not load the following classes:
 *  net.minecraft.client.Minecraft
 *  net.minecraft.entity.Entity
 *  net.minecraft.scoreboard.ScoreObjective
 *  net.minecraft.scoreboard.Scoreboard
 *  net.minecraftforge.client.event.RenderPlayerEvent$Pre
 *  net.minecraftforge.fml.common.eventhandler.SubscribeEvent
 */
package com.test.mod.module.modules.render;



import com.test.mod.Utils.Nameplate;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.module.modules.other.Teams;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.scoreboard.ScoreObjective;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;
import java.util.Queue;

public class Nametags
extends Module {


    private  Queue<Nameplate> tags;
   @SubscribeEvent
    public void onPreRender(RenderPlayerEvent.Pre event) {
        double v = 0.3;
        Scoreboard sb = event.entityPlayer.getWorldScoreboard();
        ScoreObjective sbObj = sb.getObjectiveInDisplaySlot(2);
        if (sbObj != null && !event.entityPlayer.getDisplayNameString().equals(Minecraft.getMinecraft().thePlayer.getDisplayNameString()) && event.entityPlayer.getDistanceSqToEntity((Entity)Minecraft.getMinecraft().thePlayer) < 100.0) {
            v *= 2.0;
        }
        if (!event.entityPlayer.getDisplayName().equals(Minecraft.getMinecraft().thePlayer.getDisplayName())) {

                Nameplate np = new Nameplate(event.entityPlayer.getDisplayNameString(), event.x, event.y, event.z, event.entityLiving);
                np.renderNewPlate(new Color((int)100, (int)100, (int)100));


        }
    }

    public Nametags() {
        super("Nametags", Keyboard.KEY_NONE, ModuleType.Render,false);
     }
}

