package com.test.mod.module.modules.render;

import com.test.mod.Client;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;

public class Hud extends Module {
    public static EnableSetting RainBow = new EnableSetting("RainBow",false);

    public Hud() {
        super("Hud", 0,ModuleType.Render,true);
        add(RainBow);
    }
    @SubscribeEvent
    public void onRender(RenderGameOverlayEvent.Text event) {
        int rainbowTickc = 0;
        ScaledResolution s = new ScaledResolution(mc);
        int width = new ScaledResolution(mc).getScaledWidth();
        int height = new ScaledResolution(mc).getScaledHeight();
        int y = 1;
        mc.fontRendererObj.drawStringWithShadow(Client.instance.username + " "+Client.instance.qq, width-mc.fontRendererObj.getStringWidth(Client.instance.username + " "+Client.instance.qq
        ),height-mc.fontRendererObj.FONT_HEIGHT, -1);

        ArrayList<Module> enabledModules = new ArrayList<Module>();
        for (Module m : Client.instance.moduleManager.getModules()) {
            if (m.isState()) {
                enabledModules.add(m);
            }
        }
        enabledModules.sort(new Comparator<Module>() {
            @Override
            public int compare(Module o1, Module o2) {
                return mc.fontRendererObj.getStringWidth(o2.getName()) - mc.fontRendererObj.getStringWidth(o1.getName());
            }
        });
        for (Module m : enabledModules) {
            if (m != null && m.isState()) {
                if (++rainbowTickc > 100) {
                    rainbowTickc = 0;
                }
                Color rainbow;
                rainbow = new Color(
                        Color.HSBtoRGB((float) ((double) Minecraft.getMinecraft().thePlayer.ticksExisted / 50.0
                                - Math.sin((double) rainbowTickc / 50.0 * 1.6)) % 1.0f, 0.5f, 1.0f));


                int moduleWidth = mc.fontRendererObj.getStringWidth(m.getName());

                mc.fontRendererObj.drawStringWithShadow(m.getName(), width - moduleWidth - 1, y, RainBow.getEnable()? rainbow.getRGB() : -1);
                y += mc.fontRendererObj.FONT_HEIGHT;
            }
        }
    }
}
