package com.test.mod.module.modules.render;


import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.opengl.GL11;

import java.awt.*;

public class Chams extends Module {
   public Chams() {
        super("Chams", Keyboard.KEY_NONE, ModuleType.Render,false);
   }
    @SubscribeEvent
    public void onRender(RenderPlayerEvent.Pre e){
        if (e.entity != mc.thePlayer) {
            GL11.glEnable(32823);
            GL11.glPolygonOffset(1.0F, -1100000.0F);
        }
    }

    @SubscribeEvent
    public void onRender(RenderPlayerEvent.Post e){
        if (e.entity != mc.thePlayer) {
            GL11.glDisable(32823);
            GL11.glPolygonOffset(1.0F, 1100000.0F);
        }
    }
    public static Color rainbow(final int n) {
        return Color.getHSBColor((float)(Math.ceil((System.currentTimeMillis() + n) / 20.0) % 360.0 / 360.0), 0.8f, 1.0f).brighter();
    }
    public void glColor(float n, int n2, int n3, int n4) {
        GL11.glColor4f(0.003921569f * n2, 0.003921569f * n3, 0.003921569f * n4, n);
    }
}
