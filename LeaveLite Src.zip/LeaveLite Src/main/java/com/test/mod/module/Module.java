package com.test.mod.module;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.test.mod.Utils.Connection;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.ModeSetting;
import com.test.mod.settings.Setting;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.client.Minecraft;
import net.minecraft.network.Packet;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import org.lwjgl.input.Keyboard;

import javax.swing.*;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class Module {
    public static final Minecraft mc = Minecraft.getMinecraft();
    private String name;
    private int key;
    private ModuleType moduleType;
    private boolean state;
    private ArrayList<Setting> setting;
    public Module(String name,int key,ModuleType moduleType,boolean toggle) {
        this.name = name;
        this.key = key;
        this.moduleType = moduleType;
        setting = new ArrayList<Setting>();
        if(toggle){
            setState(true,true);
        }
    }
    public boolean isToggledMode(String modeName) {
        for (Setting setting : getSettings()) {
            if (setting instanceof ModeSetting) {
                for (String mode : ((ModeSetting) setting).getModes()) {
                    if (mode.equals(modeName)) {
                        if (((ModeSetting) setting).getCurrent().equals(mode)) {
                            return true;
                        }


                    }
                }
            }
        }
        return false;
    }
    public boolean isToggledValue(String name) {
        for (Setting setting : getSettings()){
            if (setting instanceof EnableSetting){
                if (((EnableSetting) setting).getName().equals(name)){
                    return true;
                }
            }
        }
        return false;
    }
    public void onPacketEvent(ChannelHandlerContext p_channelRead0_1_, Packet p_channelRead0_2_){}
    public void send(Packet packetIn){}
    public boolean onPacket(Object packet, Connection.Side side){
        return true;
    }

    public void toggleModule(boolean send){
        this.setState(!this.state,send);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ModuleType getModuleType() {
        return moduleType;
    }

    public void setModuleType(ModuleType moduleType) {
        this.moduleType = moduleType;
    }

    public boolean isState() {
        return state;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
        JsonObject jsonObject=new JsonObject();
        jsonObject.addProperty("module",this.getName());
        jsonObject.addProperty("key", Keyboard.getKeyName(this.key));
        String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject);
        Send("127.0.0.1",20440,message);
    }

    public void setState(boolean state,boolean send) {
        if(this.state == state)return;
        this.state = state;
        if(state){
            MinecraftForge.EVENT_BUS.register(this);
            //FMLCommonHandler.instance().bus().register(this);

            JsonObject jsonObject=new JsonObject();
            jsonObject.addProperty("module",this.getName());
            jsonObject.addProperty("enable","true");
                 jsonObject.addProperty("send",send);
            String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject);
            Send("127.0.0.1",20660,message);


            this.onEnable();


        }else{
            MinecraftForge.EVENT_BUS.unregister(this);
            //FMLCommonHandler.instance().bus().unregister(this);

                JsonObject jsonObject = new JsonObject();
                jsonObject.addProperty("module", this.getName());
                jsonObject.addProperty("enable", "false");
            jsonObject.addProperty("send",send);

            String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject);
                Send("127.0.0.1", 20660, message);
                this.onDisable();


        }
    }
    public String Send(String IP, int Port, String Message) {

        try {
            Socket socket = new Socket(IP, Port);

            OutputStream ops = socket.getOutputStream();

            OutputStreamWriter opsw = new OutputStreamWriter(ops,"GBK");

            BufferedWriter bw = new BufferedWriter(opsw);

            bw.write(Message);

            bw.flush();

            InputStream ips = socket.getInputStream();

            InputStreamReader ipsr = new InputStreamReader(ips,"GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;
            socket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "LeaveOld",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
    public void add(Setting... settings) {
        for (Setting setting : settings) {
            this.setting.add(setting);
        }
    }
    public ArrayList<Setting> getSettings() {
        return setting;
    }
    public void onEnable(){

    }
    public void onDisable(){

    }
}
