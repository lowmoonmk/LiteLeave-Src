package com.test.mod.module.modules.movement;

import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

import java.util.Arrays;

public class Fly extends Module {
    private final ModeSetting Mode = new ModeSetting("Mode","Dynamic", Arrays.asList("Simple","Dynamic"),this);
    private IntegerSetting speed = new IntegerSetting("Speed",1.0D,0.1D,2.0d,1);

    public Fly() {
        super("Fly",0,ModuleType.Movement,false);
        add(Mode,speed);
    }
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if(Mode.getCurrent().equals("Dynamic")){
            if(!Tools.currentScreenMinecraft())
                return;
            EntityPlayerSP player = mc.thePlayer;
            float flyspeed = (float)speed.getCurrent();
            player.jumpMovementFactor = 0.4f;
            player.motionX = 0.0;
            player.motionY = 0.0;
            player.motionZ = 0.0;
            player.jumpMovementFactor *= (float) flyspeed * 3f;
            if (mc.gameSettings.keyBindJump.isKeyDown()) {
                player.motionY += flyspeed;
            }
            if (mc.gameSettings.keyBindSneak.isKeyDown()) {
                player.motionY -= flyspeed;
            }
        }else if(Mode.getCurrent().equals("Simple")){
            EntityPlayerSP player = mc.thePlayer;
            player.capabilities.isFlying = true;
        }

    }
    @Override
    public void onDisable() {
        if(mc.thePlayer.capabilities.isFlying){
            mc.thePlayer.capabilities.isFlying = false;
        }
        super.onDisable();
    }

}
