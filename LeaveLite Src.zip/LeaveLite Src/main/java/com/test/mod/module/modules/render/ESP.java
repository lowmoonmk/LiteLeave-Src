package com.test.mod.module.modules.render;

import com.test.mod.Utils.ColorUtils;
import com.test.mod.Utils.HUDUtils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.module.modules.other.Teams;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

import java.awt.*;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;

public class ESP extends Module {
    private static final HashMap<EntityPlayer, Long> newEnt = new HashMap<EntityPlayer, Long>();

    private final ModeSetting Mode = new ModeSetting("Mode","2D", Arrays.asList("2D","Arrow","Box","Health","Ring","Shaded"),this);
    private EnableSetting Players = new EnableSetting("Players",true);
    private EnableSetting Mobs = new EnableSetting("Mobs",false);
    private EnableSetting Animals = new EnableSetting("Animals",false);
    private EnableSetting Inv = new EnableSetting("Invisible",false);
    public ESP() {
        super("ESP",0,ModuleType.Render,false);
        add(Mode,Players,Mobs,Animals,Inv);
    }


    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event) {
        int rgb = Color.RED.getRGB();
        Iterator var3;
        var3 = mc.theWorld.loadedEntityList.iterator();
        while(true) {
            Entity en;
            do {
                do {
                    do {
                        if (!var3.hasNext()) {
                            return;
                        }

                        en = (Entity) var3.next();
                    } while(en == mc.thePlayer);
                } while(en.isDead != false);
            } while(!Inv.getEnable() && en.isInvisible());

                if (en instanceof EntityPlayer) {

                    if (Players.getEnable()) {
                        if(!Teams.isTeam(en)){

                                if (Mode.getCurrent().equals("2D")) {
                                    HUDUtils.ee(en, 3, 0.0D, 1D, Color.GREEN.getRGB(), true);
                                }
                                if (Mode.getCurrent().equals("Arrow")) {
                                    HUDUtils.ee(en, 5, 0.0D, 1D, Color.GREEN.getRGB(), true);
                                }
                                if (Mode.getCurrent().equals("Box") ) {
                                    HUDUtils.ee(en, 1, 0.0D, 1D, Color.GREEN.getRGB(), false);
                                }
                                if (Mode.getCurrent().equals("Health")) {
                                    HUDUtils.ee(en, 4, 0.0D, 1D, Color.GREEN.getRGB(), true);
                                }
                                if (Mode.getCurrent().equals("Ring")) {
                                    HUDUtils.ee(en, 6, 0.0D, 1D, Color.GREEN.getRGB(), true);
                                }
                                if (Mode.getCurrent().equals("Shaded")) {
                                    HUDUtils.ee(en, 2, 0.0D, 1D, Color.GREEN.getRGB(), true);
                                }
                                if (Mode.getCurrent().equals("CSGO")) {
                                    HUDUtils.CSGO(en,true);
                                }
                        }else {
                            if (Mode.getCurrent().equals("2D")) {
                                HUDUtils.ee(en, 3, 0.0D, 1D, rgb, true);
                            }
                            if (Mode.getCurrent().equals("Arrow")) {
                                HUDUtils.ee(en, 5, 0.0D, 1D, rgb, true);
                            }
                            if (Mode.getCurrent().equals("Box") ) {
                                HUDUtils.ee(en, 1, 0.0D, 1D, rgb, false);
                            }
                            if (Mode.getCurrent().equals("Health")) {
                                HUDUtils.ee(en, 4, 0.0D, 1D, rgb, true);
                            }
                            if (Mode.getCurrent().equals("Ring")) {
                                HUDUtils.ee(en, 6, 0.0D, 1D, rgb, true);
                            }
                            if (Mode.getCurrent().equals("Shaded")) {
                                HUDUtils.ee(en, 2, 0.0D, 1D, rgb, true);
                            }
                            if (Mode.getCurrent().equals("CSGO")) {
                                HUDUtils.CSGO(en,false);
                            }
                        }

                    }
                }
                if (en instanceof EntityAnimal) {
                    if (Animals.getEnable()) {
                        if (Mode.getCurrent().equals("2D")) {
                            HUDUtils.ee(en, 3, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Arrow")) {
                            HUDUtils.ee(en, 5, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Box")) {
                            HUDUtils.ee(en, 1, 0.0D, 1D, rgb, false);
                        }
                        if (Mode.getCurrent().equals("Health")) {
                            HUDUtils.ee(en, 4, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Ring")) {
                            HUDUtils.ee(en, 6, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Shaded")) {
                            HUDUtils.ee(en, 2, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("CSGO")) {
                            HUDUtils.CSGO(en,false);
                        }
                    }
                }
                if (en instanceof EntityMob) {
                    if (Mobs.getEnable()) {
                        if (Mode.getCurrent().equals("2D")) {
                            HUDUtils.ee(en, 3, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Arrow")) {
                            HUDUtils.ee(en, 5, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Box")) {
                            HUDUtils.ee(en, 1, 0.0D, 1D, rgb, false);
                        }
                        if (Mode.getCurrent().equals("Health")) {
                            HUDUtils.ee(en, 4, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Ring")) {
                            HUDUtils.ee(en, 6, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("Shaded")) {
                            HUDUtils.ee(en, 2, 0.0D, 1D, rgb, true);
                        }
                        if (Mode.getCurrent().equals("CSGO")) {
                            HUDUtils.CSGO(en,false);
                        }
                    }
                }






        }
    }

}
