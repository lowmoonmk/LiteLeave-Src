package com.test.mod.module.modules.combat;


import com.test.mod.Utils.TimerUtils;
import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.inventory.GuiContainerCreative;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.ContainerChest;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import java.util.Random;

public class ChestStealer extends Module {
    private TimerUtils timer=new TimerUtils();

    public int ticks;
   public IntegerSetting Delay = new IntegerSetting("Delay",200.0D,0.0D,1000.0d,1);
    private EnableSetting autoClose=new EnableSetting("AutoClose",true);
    public ChestStealer() {
        super("ChestStealer", Keyboard.KEY_NONE, ModuleType.Combat,false);
        add(Delay,autoClose);
   }
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (!Tools.isPlayerInGame())
            return;

        final Minecraft mc = ChestStealer.mc;
        if (mc.thePlayer.openContainer != null) {
            if (mc.thePlayer.openContainer instanceof ContainerChest && !(mc.currentScreen instanceof GuiInventory) && !(mc.currentScreen instanceof GuiContainerCreative)) {
                final ContainerChest container = (ContainerChest)mc.thePlayer.openContainer;
                for (int i = 0; i < container.getLowerChestInventory().getSizeInventory(); ++i) {
                    if (container.getLowerChestInventory().getStackInSlot(i) != null    ) {
                        if(timer.isDelayComplete(Delay.getCurrent()+ new Random().nextInt(100))){
                            final PlayerControllerMP playerController = mc.playerController;
                            final int windowId = container.windowId;
                            final int slotId = i;
                            final int p_78753_3_ = 0;
                            final int p_78753_4_ = 1;
                            playerController.windowClick(windowId, slotId, p_78753_3_, p_78753_4_, mc.thePlayer);
                            timer.reset();
                        }
                    }else if (this.empty(container) && autoClose.getEnable()) {
                        mc.thePlayer.closeScreen();
                    }
                }
                this.ticks += 1;
            }
        }






    }
    private boolean isEmpty() {

        if (mc.thePlayer.openContainer instanceof ContainerChest) {
            ContainerChest container = (ContainerChest) mc.thePlayer.openContainer;
            int i = 0;
            while (i < container.getLowerChestInventory().getSizeInventory()) {
                ItemStack itemStack = container.getLowerChestInventory().getStackInSlot(i);
                if (itemStack != null && itemStack.getItem() != null) {
                    return false;
                }
                ++i;
            }
        }
        return true;
    }
    private boolean isContainerEmpty(Container container) {
        boolean temp = true;
        int i = 0;
        for(int slotAmount = container.inventorySlots.size() == 90 ? 54 : 35; i < slotAmount; i++) {
            if (container.getSlot(i).getHasStack()) {
                temp = false;
            }
        }
        return temp;
    }

    public boolean empty(final Container container) {
        boolean voll = true;
        for (int i = 0, slotAmount = (container.inventorySlots.size() == 90) ? 54 : 27; i < slotAmount; ++i) {
            if (container.getSlot(i).getHasStack()) {
                voll = false;
            }
        }
        return voll;
    }
}
