package com.test.mod.module.modules.world;

import com.test.mod.Client;
import com.test.mod.Utils.BlockUtils;
import com.test.mod.Utils.Connection;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.util.*;
import net.minecraft.world.WorldSettings;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import net.minecraftforge.fml.relauncher.ReflectionHelper;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;

public class NoFall extends Module {
    private boolean aac5doFlag = false;
    private boolean aac5Check = false;
    private int aac5Timer = 0;
    private boolean isDmgFalling = false;

    private final ModeSetting Mode = new ModeSetting("Mode","AAC", Arrays.asList("AAC","Simple","AAC2","AAC5","AAC5.0.4","MLG"),this);
    private EnableSetting VOID = new EnableSetting("VOID", true);
    private IntegerSetting delay = new IntegerSetting("MLGDelay", 100.0d, 1.0d, 1000.0d,0);

    public NoFall() {
        super("NoFall",0, ModuleType.World,false);
        getSettings().add(Mode);
        getSettings().add(VOID);
        getSettings().add(delay);

    }

    @Override
    public void onEnable() {
        aac5Check = false;
        aac5doFlag = false;
        aac5Timer = 0;
        isDmgFalling = false;

        super.onEnable();
    }

    @Override
    public void onDisable() {
        aac5Check = false;
        aac5doFlag = false;
        aac5Timer = 0;
        isDmgFalling = false;
        super.onDisable();
    }
    @SubscribeEvent
    public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
        if (Mode.getCurrent().equalsIgnoreCase("MLG")) {
            if (mc.thePlayer.fallDistance > 4 && getSlotWaterBucket() != -1 && isMLGNeeded()) {
                mc.thePlayer.rotationPitch = 90f;
                swapToWaterBucket(getSlotWaterBucket());
            }

            if (mc.thePlayer.fallDistance > 4 && isMLGNeeded() && !mc.thePlayer.isOnLadder() && mc.objectMouseOver.typeOfHit == MovingObjectPosition.MovingObjectType.BLOCK) {
                BlockPos pos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - BlockUtils.getDistanceToFall() - 1, mc.thePlayer.posZ);
                this.placeWater(pos, EnumFacing.UP);


                if (mc.thePlayer.getHeldItem().getItem() == Items.bucket) {
                    Thread thr = new Thread(() -> {
                        try {
                            Thread.sleep((long) delay.getCurrent());
                        } catch (Exception ignored) {
                        }
                        rightClickMouse(mc);
                    });
                    thr.start();
                }

                mc.thePlayer.fallDistance = 0;
            }
        }
    }
    public void sendPacket(Packet packet) {
        mc.thePlayer.sendQueue.addToSendQueue(packet);
    }
    @SubscribeEvent
    public void onClientTick(ClientTickEvent event) {
        if (Mode.getCurrent().equalsIgnoreCase("Simple")) {
            if (mc.thePlayer.fallDistance > 2)
                sendPacket(new C03PacketPlayer(true));
        }


        if (Mode.getCurrent().equalsIgnoreCase("AAC2")) {
            if (mc.thePlayer.ticksExisted == 1 && mc.thePlayer.fallDistance > 2) {
                C03PacketPlayer.C04PacketPlayerPosition p = new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, Double.NaN, mc.thePlayer.posZ, true);
                mc.thePlayer.sendQueue.addToSendQueue(p);
            }

        }

        if (Mode.getCurrent().equalsIgnoreCase("AAC5")) {

            double offsetYs = 0.0;
            aac5Check = false;
            while (mc.thePlayer.motionY - 1.5 < offsetYs) {
                BlockPos blockPos = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY + offsetYs, mc.thePlayer.posZ);
                Block block = BlockUtils.getBlock(blockPos);
                AxisAlignedBB axisAlignedBB = block.getCollisionBoundingBox(mc.theWorld, blockPos, BlockUtils.getState(blockPos));
                if (axisAlignedBB != null) {
                    offsetYs = -999.9;
                    aac5Check = true;
                }
                offsetYs -= 0.5;
            }
            if (mc.thePlayer.onGround) {
                mc.thePlayer.fallDistance = -2f;
                aac5Check = false;
            }
            if (aac5Timer > 0) {
                aac5Timer -= 1;
            }
            if (aac5Check && mc.thePlayer.fallDistance > 2.5 && !mc.thePlayer.onGround) {
                aac5doFlag = true;
                aac5Timer = 18;
            } else {
                if (aac5Timer < 2) aac5doFlag = false;
            }
            if (aac5doFlag) {
                if (mc.thePlayer.onGround) {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.5, mc.thePlayer.posZ, true));
                } else {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(mc.thePlayer.posX, mc.thePlayer.posY + 0.42, mc.thePlayer.posZ, true));
                }
            }

        }

        if (Mode.getCurrent().equalsIgnoreCase("AAC5.0.4")) {
            if (mc.thePlayer.fallDistance > 3) {
                isDmgFalling = true;
            }
        }
    }

    @Override
    public boolean onPacket(Object packet, Connection.Side side) {
        if (side == Connection.Side.OUT) {
            if (packet instanceof C03PacketPlayer) {
                final C03PacketPlayer p = (C03PacketPlayer) packet;

                if (Mode.getCurrent().equalsIgnoreCase("AAC")) {
                    Field field = ReflectionHelper.findField(C03PacketPlayer.class,
                            new String[]{"onGround", "field_149474_g"});
                    try {

                        if (!field.isAccessible()) {
                            field.setAccessible(true);
                        }

                        field.setBoolean(p, true);

                    } catch (Exception e) {
                        ////System.out.println(e);
                    }
                } else if (Mode.getCurrent().equalsIgnoreCase("AAC5.0.4") && isDmgFalling) {
                    Field field = ReflectionHelper.findField(C03PacketPlayer.class,
                            new String[]{"onGround", "field_149474_g"});
                    Field fx = ReflectionHelper.findField(C03PacketPlayer.class, new String[]{"x", "field_149479_a"});
                    Field fy = ReflectionHelper.findField(C03PacketPlayer.class, new String[]{"y", "field_149477_b"});
                    Field fz = ReflectionHelper.findField(C03PacketPlayer.class, new String[]{"z", "field_149478_c"});
                    try {

                        if (!field.isAccessible()) {
                            field.setAccessible(true);
                        }
                        if (!fx.isAccessible()) {
                            fx.setAccessible(true);
                        }
                        if (!fy.isAccessible()) {
                            fy.setAccessible(true);
                        }
                        if (!fz.isAccessible()) {
                            fz.setAccessible(true);
                        }

                        if (field.getBoolean(p) && mc.thePlayer.onGround) {
                            isDmgFalling = false;
                            field.setBoolean(p, true);
                            mc.thePlayer.onGround = false;
                            double y = fy.getDouble(p);
                            double x = fx.getDouble(p);
                            double z = fx.getDouble(p);
                            fy.setDouble(p, y + 1.0);
                            // ChatUtils.message("ok");
                            sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(x, y - 1.0784, z, false));
                            sendPacket(new C03PacketPlayer.C04PacketPlayerPosition(x, y - 0.5, z, true));
                        }

                    } catch (Exception e) {
                        ////System.out.println(e);
                    }
                }

            }

        }
        return true;
    }
    public static void rightClickMouse(final Minecraft mc) {
        invoke(mc, "rightClickMouse" , "func_147121_ag", new Class[]{}, new Object[] {});
    }
    public static Object invoke(final Object target, final String methodName, final String obfName, final Class[] methodArgs, final Object[] args) {
        final Class clazz = target.getClass();
        final Method method = ReflectionHelper.findMethod(clazz, target,
                Client.isObfuscate?new String[] {  obfName }:new String[] { methodName }
                , methodArgs);
        method.setAccessible(true);
        try {
            return method.invoke(target, args);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private boolean isBlockUnderJudge() {
        for (int offset = 0; offset < mc.thePlayer.posY + mc.thePlayer.getEyeHeight(); offset += 2) {
            AxisAlignedBB boundingBox = mc.thePlayer.getEntityBoundingBox().offset(0, -offset, 0);

            if (!mc.theWorld.getCollidingBoundingBoxes(mc.thePlayer, boundingBox).isEmpty()) {
                return true;
            }
        }

        return false;
    }


    private void swapToWaterBucket(int blockSlot) {
        mc.thePlayer.inventory.currentItem = blockSlot;
        mc.thePlayer.sendQueue.getNetworkManager().sendPacket(new C09PacketHeldItemChange(blockSlot));
    }

    private int getSlotWaterBucket() {
        for (int i = 0; i < 8; i++) {
            if (mc.thePlayer.inventory.mainInventory[i] != null && mc.thePlayer.inventory.mainInventory[i].getItem().getUnlocalizedName().contains("bucketWater"))
                return i;
        }
        return -1;
    }

    private void placeWater(BlockPos pos, EnumFacing facing) {
        ItemStack heldItem = mc.thePlayer.inventory.getCurrentItem();
        mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.inventory.getCurrentItem(), pos, facing, new Vec3((double) pos.getX() + 0.5, (double) pos.getY() + 1, (double) pos.getZ() + 0.5));
        if (heldItem != null) {
            mc.playerController.sendUseItem(mc.thePlayer, mc.theWorld, heldItem);
            mc.entityRenderer.itemRenderer.resetEquippedProgress2();
        }
    }

    private boolean isMLGNeeded() {
        if (mc.playerController.getCurrentGameType() == WorldSettings.GameType.CREATIVE || mc.playerController.getCurrentGameType() == WorldSettings.GameType.SPECTATOR || mc.thePlayer.capabilities.isFlying || mc.thePlayer.capabilities.allowFlying)
            return false;

        for (double y = mc.getMinecraft().thePlayer.posY; y > 0.0; --y) {
            final Block block = BlockUtils.getBlock(new BlockPos(mc.getMinecraft().thePlayer.posX, y, mc.getMinecraft().thePlayer.posZ));
            if (block.getMaterial() == Material.water) {
                return false;
            }

            if (block.getMaterial() != Material.air)
                return true;

            if (y < 0.0) {
                break;
            }
        }

        return true;
    }
}
