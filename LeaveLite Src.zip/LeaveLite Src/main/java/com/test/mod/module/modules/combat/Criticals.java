package com.test.mod.module.modules.combat;

import com.test.mod.Client;
import com.test.mod.Utils.ChatUtils;
import com.test.mod.Utils.Connection;
import com.test.mod.Utils.TimerUtils;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.server.S0BPacketAnimation;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Arrays;
public class Criticals extends Module {
    public ModeSetting mode = new ModeSetting("Mode", "Visual", Arrays.asList("AutoJump", "Packet", "NewPacket", "NcpPacket", "Hop", "TPHop", "Jump", "LowJump", "Visual"), this);
    private IntegerSetting hurtTimeValue = new IntegerSetting("HurtTime", 10D, 0D, 10D, 1);

    private IntegerSetting delayValue = new IntegerSetting("Delay", 0D, 0D, 500D, 1);

    public static EnableSetting debug = new EnableSetting("DeBug", true);

    TimerUtils timerUtils = new TimerUtils();

    int target1 = 0;

    public Criticals() {
        super("Criticals", 0, ModuleType.Combat, false);
        add(mode, hurtTimeValue, delayValue, debug);
    }

    @Override
    public void onDisable() {
        super.onDisable();
    }

    @Override
    public void onEnable() {
        super.onEnable();
    }

    @SubscribeEvent
    public void onAttackEntity(AttackEntityEvent event) {
        if (event.target instanceof EntityLivingBase) {
            target1 = event.target.getEntityId();
            if (!mc.thePlayer.onGround || mc.thePlayer.isOnLadder() || mc.thePlayer.isInWater() ||
                    mc.thePlayer.isInLava() || mc.thePlayer.ridingEntity != null || ((EntityLivingBase) event.target).hurtTime > hurtTimeValue.getCurrent() || !timerUtils.isDelay((long) delayValue.getCurrent())) {
                return;
            }

            double x = mc.thePlayer.posX;
            double y = mc.thePlayer.posY;
            double z = mc.thePlayer.posZ;

            switch (mode.getCurrent().toLowerCase()) {
                case "autojump": {
                    mc.thePlayer.jump();
                }

                case "packet": {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.0625, z, true));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 1.1E-5, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y, z, false));
                }

                case "newpacket": {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.05250000001304, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.00150000001304, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01400000001304, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.00150000001304, z, false));
                }

                case "ncppacket": {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.11, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.1100013579, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.0000013579, z, false));
                }

                case "hop": {
                    mc.thePlayer.motionY = 0.1;
                    mc.thePlayer.fallDistance = 0.1f;
                    mc.thePlayer.onGround = false;
                }

                case "tphop": {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.02, z, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(x, y + 0.01, z, false));
                    mc.thePlayer.setPosition(x, y + 0.01, z);
                }

                case "jump": {
                    mc.thePlayer.motionY = 0.42;
                }

                case "lowjump": {
                    mc.thePlayer.motionY = 0.3425;
                }

                case "visual": {
                    mc.thePlayer.onCriticalHit(event.target);
                    mc.thePlayer.onEnchantmentCritical(event.target);
                }
            }
            timerUtils.reset();
        }
    }

    @Override
    public boolean onPacket(Object packet, Connection.Side side) {
        if (debug.getEnable()) {
            if (packet instanceof S0BPacketAnimation) {
                if (((S0BPacketAnimation) packet).getAnimationType() == 4 && ((S0BPacketAnimation) packet).getEntityID() == target1) {
                    ChatUtils.message("TriggerCritical");
                }
            }
        }
        return true;
    }
}
