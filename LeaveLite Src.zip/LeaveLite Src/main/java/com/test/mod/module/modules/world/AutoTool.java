package com.test.mod.module.modules.world;


import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemShears;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemTool;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class AutoTool extends Module {
    public static int previousSlot;
    public static boolean justFinishedMining, mining;
    public AutoTool() {
        super("AutoTool", Keyboard.KEY_NONE, ModuleType.World,false);
   }
    @SubscribeEvent
    public void onRenderWorldLast(RenderWorldLastEvent event)  {
        if (!Tools.isPlayerInGame() )
            return;

        ////////System.out.println(mc.currentScreen);

        if(Mouse.isButtonDown(0)) {


            BlockPos lookingAtBlock = mc.objectMouseOver.getBlockPos();
            if (lookingAtBlock != null) {
                Block stateBlock = mc.theWorld.getBlockState(lookingAtBlock).getBlock();
                if (stateBlock != Blocks.air && !(stateBlock instanceof BlockLiquid) && stateBlock instanceof Block) {
                    if(!mining) {
                        previousSlot = Tools.getCurrentPlayerSlot();
                        mining = true;
                    }
                    int index = -1;
                    double speed = 1;


                    for (int slot = 0; slot <= 8; slot++) {
                        ItemStack itemInSlot = mc.thePlayer.inventory.getStackInSlot(slot);
                        if(itemInSlot != null && itemInSlot.getItem() instanceof ItemTool) {
                            BlockPos p = mc.objectMouseOver.getBlockPos();
                            Block bl = mc.theWorld.getBlockState(p).getBlock();

                            if(itemInSlot.getItem().getDigSpeed(itemInSlot, bl.getDefaultState()) > speed) {
                                speed = itemInSlot.getItem().getDigSpeed(itemInSlot, bl.getDefaultState());
                                index = slot;
                            }
                        }
                        else if(itemInSlot != null && itemInSlot.getItem() instanceof ItemShears) {
                            BlockPos p = mc.objectMouseOver.getBlockPos();
                            Block bl = mc.theWorld.getBlockState(p).getBlock();

                            if(itemInSlot.getItem().getDigSpeed(itemInSlot, bl.getDefaultState()) > speed) {
                                speed = itemInSlot.getItem().getDigSpeed(itemInSlot, bl.getDefaultState());
                                index = slot;
                            }
                        }
                    }

                    if(index == -1 || speed <= 1.1 || speed == 0) {
                    } else {
                        Tools.hotkeyToSlot(index);
                    }
                }
                else{
                }
            }
            else {
            }


        }
        else {
            if(mining)

                    Tools.hotkeyToSlot(previousSlot);

            justFinishedMining = false;
            mining = false;
        }


    }
}
