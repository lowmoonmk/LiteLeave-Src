package com.test.mod.module;

public enum ModuleType {
    Combat,
    Movement,
    Render,
    World,
    Other
}
