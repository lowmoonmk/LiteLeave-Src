package com.test.mod.module.modules.render;


import com.test.mod.Utils.Tools;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class FullBright extends Module {
    private float old;
    public FullBright() {
        super("FullBright", Keyboard.KEY_NONE, ModuleType.Render,false);
    }
    @Override
    public void onEnable() {
        this.old = mc.gameSettings.gammaSetting;
        super.onEnable();
    }
    @Override
    public void onDisable(){
        super.onEnable();
        mc.gameSettings.gammaSetting = this.old;
    }
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if(!Tools.isPlayerInGame()){
            onEnable();
            return;
        }

        if (mc.gameSettings.gammaSetting != 10000)
            mc.gameSettings.gammaSetting = 10000;
    }
}
