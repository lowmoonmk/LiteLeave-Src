package com.test.mod.event;

import com.test.mod.Client;
import com.test.mod.Utils.Connection;
import com.test.mod.module.Module;
import net.minecraft.client.Minecraft;

public class Event {
    public Event() {

    }

    public boolean onPacket(Object packet, Connection.Side side){
        boolean suc = true;
        for (Module module : Client.instance.moduleManager.getModules()) {
            if (!module.isState() || Minecraft.getMinecraft().theWorld == null) {
                continue;
            }
            suc &= module.onPacket(packet, side);

        }
        return suc;
    }
}
