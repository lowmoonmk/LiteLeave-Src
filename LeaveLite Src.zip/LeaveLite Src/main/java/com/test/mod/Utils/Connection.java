package com.test.mod.Utils;

import com.test.mod.Client;
import io.netty.channel.*;
import net.minecraft.client.Minecraft;

public class Connection extends ChannelDuplexHandler {
    public enum Side {IN, OUT;}

    public Connection() {
        try {
            ChannelPipeline pipeline = Minecraft.getMinecraft().getNetHandler().getNetworkManager().channel().pipeline();
            pipeline.addBefore("packet_handler", "PacketHandler", (ChannelHandler) this);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object packet) throws Exception {
        /*
        if (packet instanceof C08PacketPlayerBlockPlacement) {
            C08PacketPlayerBlockPlacement c08PacketPlayerBlockPlacement = (C08PacketPlayerBlockPlacement) packet;
            float facingX = ReflectionHelper.getPrivateValue(C08PacketPlayerBlockPlacement.class, c08PacketPlayerBlockPlacement, "facingX", "field_149577_f");
            float facingY = ReflectionHelper.getPrivateValue(C08PacketPlayerBlockPlacement.class, c08PacketPlayerBlockPlacement, "facingY", "field_149578_g");
            float facingZ = ReflectionHelper.getPrivateValue(C08PacketPlayerBlockPlacement.class, c08PacketPlayerBlockPlacement, "facingZ", "field_149584_h");
            ReflectionHelper.setPrivateValue(C08PacketPlayerBlockPlacement.class,c08PacketPlayerBlockPlacement,(float) c08PacketPlayerBlockPlacement.getPlacedBlockDirection() / 1.0F,"facingX","field_149577_f");
            ReflectionHelper.setPrivateValue(C08PacketPlayerBlockPlacement.class,c08PacketPlayerBlockPlacement,(float) c08PacketPlayerBlockPlacement.getPlacedBlockDirection() / 1.0F,"facingY","field_149578_g");
            ReflectionHelper.setPrivateValue(C08PacketPlayerBlockPlacement.class,c08PacketPlayerBlockPlacement,(float) c08PacketPlayerBlockPlacement.getPlacedBlockDirection() / 1.0F,"facingZ","field_149584_h");

        }

         */
        if(!Client.instance.event.onPacket(packet, Side.IN)) return;
        super.channelRead(ctx, packet);
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object packet, ChannelPromise promise) throws Exception {
        if(!Client.instance.event.onPacket(packet, Side.OUT)) return;
        super.write(ctx, packet,promise);
    }
}
