package com.test.mod.Utils;

public class EntitySize {
	public float width;
	public float height;
	
	public EntitySize(float width, float height) {
		this.width = width;
		this.height = height;
	}
}
