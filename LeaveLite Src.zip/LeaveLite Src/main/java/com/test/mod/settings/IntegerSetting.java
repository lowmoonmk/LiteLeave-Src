package com.test.mod.settings;


import com.test.mod.module.Module;

public class IntegerSetting extends Setting {
    private final double min;
    private final double max;
    private double current;
    private Module parent;
    private int dou;
    public IntegerSetting(String name, double current, double min, double max,int dou) {
        super(name);
        this.current = current;
        this.min = min;
        this.max = max;
        this.dou = dou;
    }

    public int getDou() {
        return dou;
    }

    public void setDou(int dou) {
        this.dou = dou;
    }

    public double getCurrent() {
        return current;
    }
    public Module getParentMod(){
        return parent;
    }
    public void setCurrent(double current) {
        this.current = current;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }
}
