package com.test.mod.config.configs;

import com.test.mod.Client;
import com.test.mod.Utils.Tools;
import com.test.mod.config.ConfigManager;
import com.test.mod.module.Module;

public class ModuleConfig {
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(),"modules.txt");

    public static void loadModules(){
        try {

            for (String s : configManager.read()) {

                for (Module module : Client.instance.moduleManager.getModules()) {
                    String name = s.split(":")[0];

                    boolean toggled = Boolean.parseBoolean(s.split(":")[1]);

                    if (module.getName().equalsIgnoreCase(name)  && module.getName() != "ClickGui") {
                        module.setState(toggled,false);
                    }
                }
            }
        } catch (Exception e) {
        }
    }
    public static void saveModules(){
        try{
            configManager.clear();
            for(Module module : Client.instance.moduleManager.getModules()){
                if(module.getName() != "ClickGUI"){
                    String line = (module.getName() + ":" + String.valueOf(module.isState()));
                    configManager.write(line);
                }

            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
