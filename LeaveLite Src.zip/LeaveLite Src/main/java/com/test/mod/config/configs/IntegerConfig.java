package com.test.mod.config.configs;

import com.test.mod.Client;
import com.test.mod.Utils.Tools;
import com.test.mod.config.ConfigManager;
import com.test.mod.module.Module;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.Setting;

public class IntegerConfig {
   // private static Module module;
    //final List<Setting> settingList = new ArrayList<>();
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(),"Integer.txt");
    public static void saveState() {
        try {
            configManager.clear();
            for(Module module : Client.instance.moduleManager.getModules()){
                if(!module.getSettings().isEmpty()){
                    for (Setting setting : module.getSettings()) {
                        if(setting instanceof IntegerSetting){
                            String line = setting.getName() + ":"+module.getName()+":"+ ((IntegerSetting) setting).getCurrent();
                            configManager.write(line);
                        }
                        /*
                        if(setting instanceof EnableSetting){
                            String line = setting.getName() + ":"+((EnableSetting) setting).getEnable();
                            configManager.write(line);
                        }else
                         */
                        //String line = (((IntegerSetting) setting).getName() + ":" +  String.valueOf(((IntegerSetting) setting).getCurrent()));

                    }
                }

            }

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    public static void loadState() {
        try {
            for (String s : configManager.read()) {

                for(Module module : Client.instance.moduleManager.getModules()) {
                    if (!module.getSettings().isEmpty()) {
                        for (Setting setting : module.getSettings()) {
                            String name = s.split(":")[0];
                            String mod = s.split(":")[1];
                            double value = Double.parseDouble(s.split(":")[2]);
                            if (setting.getName().equalsIgnoreCase(name) && module.getName().equalsIgnoreCase(mod)){

                                ((IntegerSetting) setting).setCurrent(value);

                            }

                        }

                    }
                }
                /*
                for (Setting setting : Client.instance.module.getSettings()) {
                    String name = s.split(":")[0];
                    String modname = s.split(":")[1];
                    double value = Double.parseDouble(s.split(":")[2]);
                    if (setting.getName().equalsIgnoreCase(name) && ((IntegerSetting) setting).getParentMod().getName().equalsIgnoreCase(modname)) {
                        ((IntegerSetting) setting).setCurrent(value);
                    }
                }

                 */
            }
        } catch (Exception e) {
        }
    }
}
