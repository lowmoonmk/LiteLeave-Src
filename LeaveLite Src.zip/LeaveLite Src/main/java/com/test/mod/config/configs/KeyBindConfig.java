package com.test.mod.config.configs;

import com.test.mod.Client;
import com.test.mod.Utils.Tools;
import com.test.mod.config.ConfigManager;
import com.test.mod.module.Module;

public class KeyBindConfig {
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(),"KeyBind.txt");

    public static void saveKey() {
        try {
            configManager.clear();
            for(Module module : Client.instance.moduleManager.getModules()){
                String line = module.getName() + ":" + module.getKey();
                configManager.write(line);
            }

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public static void loadKey() {
        try {
            for (String s : configManager.read()) {
                for(Module module : Client.instance.moduleManager.getModules()) {
                    String name = s.split(":")[0];
                    int key = Integer.parseInt( s.split(":")[1]);
                    if(module.getName().equalsIgnoreCase(name)){
                        module.setKey(key);
                    }
                }

            }
        } catch (Exception e) {
        }
    }

}
