package com.test.mod.config.configs;

import com.test.mod.Client;
import com.test.mod.Utils.Tools;
import com.test.mod.config.ConfigManager;
import com.test.mod.module.Module;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.Setting;

public class EnableConfig {
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(),"Enable.txt");
    public static void saveState() {
        try {
            configManager.clear();
            for(Module module : Client.instance.moduleManager.getModules()){
                if(!module.getSettings().isEmpty()){
                    for (Setting setting : module.getSettings()) {
                        if(setting instanceof EnableSetting){
                            String line = setting.getName() + ":"+ module.getName()+":"+((EnableSetting) setting).getEnable();
                            configManager.write(line);
                        }
                    }
                }

            }

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    public static void loadState() {
        try {
            for (String s : configManager.read()) {
                for(Module module : Client.instance.moduleManager.getModules()) {
                    if (!module.getSettings().isEmpty()) {
                        for (Setting setting : module.getSettings()) {
                            String name = s.split(":")[0];
                            boolean enable = false;
                            String mod = s.split(":")[1];
                            boolean toggled = Boolean.parseBoolean(s.split(":")[2]);
                            if (setting.getName().equalsIgnoreCase(name) && module.getName().equalsIgnoreCase(mod)){
                                ((EnableSetting) setting).setEnable(toggled);
                            }
                        }

                    }
                }

            }
        } catch (Exception e) {
        }
    }
}
