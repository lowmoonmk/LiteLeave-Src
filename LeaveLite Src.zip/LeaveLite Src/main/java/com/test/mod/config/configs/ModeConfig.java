package com.test.mod.config.configs;


import com.test.mod.Client;
import com.test.mod.Utils.Tools;
import com.test.mod.config.ConfigManager;
import com.test.mod.module.Module;
import com.test.mod.settings.ModeSetting;
import com.test.mod.settings.Setting;

public class ModeConfig {
    private static ConfigManager configManager = new ConfigManager(Tools.getConfigPath(),"Mode.txt");

    public static void saveState() {
        try {
            configManager.clear();
            for(Module module : Client.instance.moduleManager.getModules()){
                if(!module.getSettings().isEmpty()){
                    for (Setting setting : module.getSettings()) {
                        if(setting instanceof ModeSetting){
                            String line = setting.getName() + ":"+ module.getName()+":"+((ModeSetting) setting).getCurrent();
                            configManager.write(line);
                        }
                    }
                }

            }

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    public static void loadState() {
        try {

            for (String s : configManager.read()) {
                for(Module module : Client.instance.moduleManager.getModules()) {
                    if (!module.getSettings().isEmpty()) {
                        for (Setting setting : module.getSettings()) {
                            String name = s.split(":")[0];
                            String mod = s.split(":")[1];
                            String value  = s.split(":")[2];
                            if (setting.getName().equalsIgnoreCase(name) && ((ModeSetting) setting).getParent().getName().equalsIgnoreCase(mod)){
                                ((ModeSetting) setting).setCurrent(value);
                                //System.out.println(setting.getName()+"   "+value+"   "+((ModeSetting) setting).getCurrent());

                            }

                        }

                    }
                }

            }
        } catch (Exception e) {
        }
    }
}
