package com.test.mod.config;


import com.test.mod.Utils.Tools;

import java.io.*;
import java.util.ArrayList;

public class ConfigManager {
    public String path;
    public String filename;
    public ConfigManager(String path,String filename) {
        this.path = path;
        this.filename = filename;
        this.createFile();

    }
    public void createFile(){
        try {
            File n = new File(path+"\\"+filename);
            File ConfigDir = new File(Tools.getConfigPath());
            if(!ConfigDir.exists()){
                ConfigDir.mkdir();
            }
            File FontDir = new File(Tools.getFontPath());
            if(!FontDir.exists()){
                FontDir.mkdir();
            }
            if(!n.exists()){
                n.createNewFile();
            }

        }catch (Exception e){

        }

    }
    public void clear() {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File(path, filename)));
            bw.write("");
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void write(String text) {
        write(new String[]{text});
    }
    public final ArrayList<String> read() {
        ArrayList<String> list = new ArrayList<String>();
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(path, filename).getAbsolutePath()))));
            while (true) {
                String text = br.readLine();
                if (text != null) {
                    list.add(text.trim());
                } else {
                    break;
                }
            }
            br.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    public void write(String[] text) {
        if (text == null || text.length == 0 || text[0].trim() == "") {
            return;
        }
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(new File(path, filename), true));
            for (String line : text) {
                bw.write(line);
                bw.write("\r\n");
            }
            bw.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
