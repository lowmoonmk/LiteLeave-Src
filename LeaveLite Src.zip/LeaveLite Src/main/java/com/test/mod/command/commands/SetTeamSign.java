package com.test.mod.command.commands;

import com.test.mod.Utils.ChatUtils;
import com.test.mod.command.Command;

import net.minecraft.client.Minecraft;
import net.minecraft.network.EnumConnectionState;
import net.minecraft.network.handshake.client.C00Handshake;
import net.minecraft.network.login.client.C00PacketLoginStart;

import java.lang.reflect.Field;

public class SetTeamSign extends Command {
	public static String teamsign;

	@Override
	public String getName() {
		return "setteamsign";
	}

	@Override
	public void execute(String[] args) {
		teamsign = args[0];
		ChatUtils.message("New TeamSign: " +teamsign);

	}

	@Override
	public String getDesc() {
		return "set team sign for Team TabList Mode";
	}

	@Override
	public String getSyntax() {
		return ".setteamsign <name>";
	}
}
