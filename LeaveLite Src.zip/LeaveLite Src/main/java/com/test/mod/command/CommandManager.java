package com.test.mod.command;


import com.test.mod.command.commands.Bind;
import com.test.mod.command.commands.Help;
import com.test.mod.command.commands.Toggle;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.util.EnumChatFormatting;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CommandManager {

    public NetHandlerPlayClient sendQueue;
    private static CommandManager me = new CommandManager();
    private List<Command> commands = new ArrayList();
    private String prefix = ".";

    public CommandManager() {
        add(new Bind());
        add(new Help());
        add(new Toggle());
    }

    public void add(Command command) {
        this.commands.add(command);
    }

    public static CommandManager get() {
        return me;
    }

    public String getPrefix() {
        return this.prefix;
    }

    public List<Command> getCommands() {
        return this.commands;
    }

    public boolean execute(String text) {


        if (!text.startsWith(prefix)) {
            return false;
        }

        text = text.substring(1);

        String[] arguments = text.split(" ");
        String ranCmd = arguments[0];
        for (Command cmd : this.commands) {
            if (cmd.getName().equalsIgnoreCase(arguments[0])) {
                String[] args = (String[]) Arrays.copyOfRange(arguments, 1, arguments.length);
                String[] args1 = text.split(" ");
                cmd.execute(args);
                return true;
            }
        }
        Command.msg("The command" +EnumChatFormatting.AQUA+ ranCmd + EnumChatFormatting.GREEN +" has not been found!");

        return false;
    }
}
