package com.test.mod.command.commands;



import com.test.mod.Client;
import com.test.mod.Utils.ChatUtils;
import com.test.mod.command.Command;
import com.test.mod.module.Module;
import org.lwjgl.input.Keyboard;


public class Bind extends Command {

    public void execute(String[] args) {

        try
        {
            if (args.length == 0) {
                msg(getAll());
            }else if(args.length ==2){
                for(Module module : Client.instance.moduleManager.getModules()) {
                    if(module.getName().equalsIgnoreCase(args[0])) {
                        module.setKey(Keyboard.getKeyIndex((args[1].toUpperCase())));

                        ChatUtils.message(module.getName() + " key changed to \u00a79" + Keyboard.getKeyName(module.getKey()));
                    }
                }
            }



        }
        catch(Exception e)
        {
            ChatUtils.error("Usage: " + getSyntax());
        }

    }


    public String getName() {
        return "bind";
    }

    public String getSyntax() {
        return ".bind <module> <key>";
    }

    public String getDesc() {
        return "Sets binds for modules.";
    }

    public String getAll() {
        return getSyntax() + " - " + getDesc();
    }
}
