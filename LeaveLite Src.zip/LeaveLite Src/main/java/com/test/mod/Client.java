package com.test.mod;

import com.test.mod.Utils.Connection;
import com.test.mod.Utils.Tools;
import com.test.mod.command.CommandManager;
import com.test.mod.event.Event;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleManager;
import com.test.mod.run.RunSocket;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

import javax.swing.*;
import java.io.*;
import java.lang.reflect.Field;
import java.net.Socket;

public enum Client {
    instance;
    private boolean init;
    public ModuleManager moduleManager;
    public CommandManager commandManager;
    public Event event;
    public static boolean isObfuscate = false;
    public static boolean isLogin = false;
    public String username = null;
    public String qq = null;
    public void run(){
        MinecraftForge.EVENT_BUS.register(this);
        FMLCommonHandler.instance().bus().register(this);
        Client.isLogin = true;
        Client.instance.moduleManager = new ModuleManager();
        Client.instance.commandManager = new CommandManager();
        Client.instance.event = new Event();
        Client.instance.moduleManager.loadModules();
        Client.instance.setOBF();
        this.Send("127.0.0.1",20660,"I am Leave Lite",false);
        new RunSocket();
    }
    public String Send(String IP, int Port, String Message,boolean login) {

        try {
            Socket socket = new Socket(IP, Port);
            OutputStream ops = socket.getOutputStream();
            OutputStreamWriter opsw = new OutputStreamWriter(ops,"GBK");
            BufferedWriter bw = new BufferedWriter(opsw);
            bw.write(Message);
            bw.flush();
            InputStream ips = socket.getInputStream();
            InputStreamReader ipsr = new InputStreamReader(ips,"GBK");
            BufferedReader br = new BufferedReader(ipsr);
            String s = null;
            socket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "LeaveOld",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if(Tools.nullCheck()){
            init=false;
            return;
        }
        if(!init){
            new Connection();
            init=true;
        }

    }
    public void setOBF(){
        Field F;
        try {
            F= S18PacketEntityTeleport.class.getDeclaredField("field_149456_b");
            isObfuscate=true;
        } catch (NoSuchFieldException ex) {
            try {
                F= S18PacketEntityTeleport.class.getDeclaredField("posX");
                isObfuscate=false;
            } catch (NoSuchFieldException e) {
                e.printStackTrace();
            }
        }
    }
    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent keyInputEvent){
        int key = Keyboard.getEventKey();
        if(key == Keyboard.KEY_NONE) return;
        if(Keyboard.getEventKeyState()){
            for(Module module : moduleManager.getModules()){
                if(module.getKey() == key){
                    module.toggleModule(false);
                }
            }
        }
    }

}
