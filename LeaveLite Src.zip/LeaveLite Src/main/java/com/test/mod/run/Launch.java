package com.test.mod.run;

import com.test.mod.Client;

import javax.swing.*;

public class Launch {

    public Launch() {//Main class
        Client.instance.run();
    }

    public static void Load(String a,String b){
       // Client.instance.username = username;
        new Launch();
    }
}
