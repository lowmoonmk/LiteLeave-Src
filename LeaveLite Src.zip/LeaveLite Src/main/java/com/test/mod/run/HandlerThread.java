package com.test.mod.run;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.test.mod.Client;
import com.test.mod.Utils.ChatUtils;
import com.test.mod.command.CommandManager;
import com.test.mod.config.configs.*;
import com.test.mod.event.Event;
import com.test.mod.module.Module;
import com.test.mod.module.ModuleManager;
import com.test.mod.settings.EnableSetting;
import com.test.mod.settings.IntegerSetting;
import com.test.mod.settings.ModeSetting;
import com.test.mod.settings.Setting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import org.lwjgl.input.Keyboard;

import javax.swing.*;
import java.io.*;
import java.net.Socket;

public class HandlerThread  extends Thread{
    private Socket socket;

    public HandlerThread(Socket socket) {
        this.socket = socket;
    }
    @Override
    public void run() {
        try{
            InputStream inputStream=socket.getInputStream();
            InputStreamReader ipsr = new InputStreamReader(inputStream,"GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;
            while ((s = br.readLine()) != null) {

                JsonObject jsonObject=new Gson().fromJson(s,JsonObject.class);
                String module;
                boolean enable;
                String key;
                if (jsonObject.has("Operation")){
                    if(jsonObject.get("Operation").getAsString().equals("kick")){
                        Minecraft.getMinecraft().thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY, false));
                    }
                    if(jsonObject.get("Operation").getAsString().equals("Login")){
                        String username = jsonObject.get("Username").getAsString();
                        String password = jsonObject.get("Password").getAsString();
                        String hwid = jsonObject.get("HWID").getAsString();
                        String IP = jsonObject.get("IP").getAsString();
                        JsonObject jsonObject_Login = new JsonObject();
                        jsonObject_Login.addProperty("type","LOGIN");
                        jsonObject_Login.addProperty("username",username);
                        jsonObject_Login.addProperty("password",password);
                        jsonObject_Login.addProperty("hwid",hwid);
                        //jsonObject_Login.addProperty("encode","false");
                        String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject_Login);
                        System.out.println(s);
                        // Load(IP,message);
                        // this.Send("114.132.227.94",12892,message,true);
                    }
                }
                if (jsonObject.has("Config")){
                    if(jsonObject.get("Config").getAsString().equals("save")){
                        EnableConfig.saveState();
                        IntegerConfig.saveState();
                        KeyBindConfig.saveKey();
                        ModeConfig.saveState();
                        ModuleConfig.saveModules();
                    }else if(jsonObject.get("Config").getAsString().equals("load")){
                        EnableConfig.loadState();
                        IntegerConfig.loadState();
                        KeyBindConfig.loadKey();
                        ModeConfig.loadState();
                        ModuleConfig.loadModules();
                        for (Module module1 :  Client.instance.moduleManager.getModules()){
                            JsonObject jsonObject_mod=new JsonObject();
                            jsonObject_mod.addProperty("module",module1.getName());
                            jsonObject_mod.addProperty("enable",module1.isState());
                            String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject_mod);

                            this.Send("127.0.0.1",20660,message,false);

                        }
                        for (Module module1 :  Client.instance.moduleManager.getModules()){
                            JsonObject jsonObject_setting=new JsonObject();
                            if (!module1.getSettings().isEmpty()){
                                for(Setting setting : module1.getSettings()){
                                    jsonObject_setting.addProperty("setting_module",module1.getName());
                                    if(setting instanceof EnableSetting){
                                        jsonObject_setting.addProperty(setting.getName(), ((EnableSetting) setting).getEnable());
                                    }else if(setting instanceof IntegerSetting){
                                        jsonObject_setting.addProperty(setting.getName(), ((IntegerSetting) setting).getCurrent());
                                    }else if(setting instanceof ModeSetting){
                                        jsonObject_setting.addProperty(setting.getName(), ((ModeSetting) setting).getCurrent());
                                    }
                                }
                                String message = new GsonBuilder().setPrettyPrinting().create().toJson(jsonObject_setting);
                                this.Send("127.0.0.1",20550,message,false);
                            }


                        }
                        for (Module module1 :  Client.instance.moduleManager.getModules()){
                            JsonObject jsonObject_mod=new JsonObject();
                            jsonObject_mod.addProperty("module",module1.getName());
                            jsonObject_mod.addProperty("key",Keyboard.getKeyName(module1.getKey()));
                        }
                        this.Send("127.0.0.1",20660,"Config Loaded",false);

                    }
                }
            }
        }catch (Exception e){

        }

    }
    public void Load(String IP,String message) {

        try{
            System.out.println(message);
            Socket socket = new Socket(IP, 12892);

            OutputStream ops = socket.getOutputStream();

            OutputStreamWriter opsw = new OutputStreamWriter(ops);

            BufferedWriter bw = new BufferedWriter(opsw);
            bw.write(message);
            bw.flush();
            InputStream ips = socket.getInputStream();

            InputStreamReader ipsr = new InputStreamReader(ips, "GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;


            while ((s = br.readLine()) != null) {
                System.out.println(s);
                JsonObject jsonObject=new Gson().fromJson(s,JsonObject.class);
                if(jsonObject.get("type").getAsString().equals("LOGIN")) {
                    String return_message = jsonObject.get("message").getAsString();
                    if(return_message.equals("SUCCESS")){
                        Client.isLogin = true;
                        Client.instance.moduleManager = new ModuleManager();
                        Client.instance.commandManager = new CommandManager();
                        Client.instance.event = new Event();
                        Client.instance.moduleManager.loadModules();
                        Client.instance.setOBF();
                        this.Send("127.0.0.1",20660,"I am Leave Lite",false);
                    }else{
                        JOptionPane.showMessageDialog(null, "Login Failed", "Leave_Lite",
                                JOptionPane.ERROR_MESSAGE);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Unknown error", "Leave_Lite",
                            JOptionPane.ERROR_MESSAGE);
                }

            }

            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "Leave_Lite",
                    JOptionPane.ERROR_MESSAGE);
        }


    }
    public String Send(String IP, int Port, String Message,boolean login) {

        try {
            Socket socket = new Socket(IP, Port);

            OutputStream ops = socket.getOutputStream();

            OutputStreamWriter opsw = new OutputStreamWriter(ops,"GBK");

            BufferedWriter bw = new BufferedWriter(opsw);

            bw.write(Message);

            bw.flush();

            InputStream ips = socket.getInputStream();

            InputStreamReader ipsr = new InputStreamReader(ips,"GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;

            socket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "LeaveOld",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }
}
