package com.test.mod.run;

import javax.swing.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class RunSocket extends Thread{
    public RunSocket() {
        new Thread(this).start();

    }

    @Override
    public void run() {
        try {
            ServerSocket serverSocket = new ServerSocket(18899);
            Send("127.0.0.1",20660,"Connect success");
            while(true) {
                Socket client = serverSocket.accept();
                new HandlerThread(client).run();
            }
        } catch (Exception var2) {
            var2.printStackTrace();
        }
    }
    public String Send(String IP, int Port, String Message) {

        try {
            Socket socket = new Socket(IP, Port);

            OutputStream ops = socket.getOutputStream();

            OutputStreamWriter opsw = new OutputStreamWriter(ops,"GBK");

            BufferedWriter bw = new BufferedWriter(opsw);

            bw.write(Message);

            bw.flush();

            InputStream ips = socket.getInputStream();

            InputStreamReader ipsr = new InputStreamReader(ips,"GBK");

            BufferedReader br = new BufferedReader(ipsr);

            String s = null;

            socket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Failed Connect to The Server", "LeaveOld",
                    JOptionPane.ERROR_MESSAGE);
        }
        return null;
    }

}
